package com.socgen.bsc.dpc.jobmon.entries

import com.socgen.bsc.dpc.jobmon.JobMon

import scala.collection.mutable.{Map => MMap}


/** Register useful information about a Spark Executor. */
case class ExecutorEntry
(
    // Basic info
    val executorId: String,
    val executorHost: String,
    val totalCores: Int,

    // Lifespan
    val executorStartTime: Long,
    var executorEndTime: Long = -1,
    var removedReason: Option[String] = None,

    // Metrics

    val executorRunTime: MMap[Long, Long] = MMap[Long, Long](),
    val executorCpuTime: MMap[Long, Long] = MMap[Long, Long](),
    var totalExecutorRunTime: Long = 0,
    var totalExecutorCpuTime: Long = 0,

    val bytesRead: MMap[Long, Long] = MMap[Long, Long](),
    val bytesWritten: MMap[Long, Long] = MMap[Long, Long](),
    var totalExecutorBytesRead: Long = 0,
    var totalExecutorBytesWritten: Long = 0,

    var peakMemory: MMap[Long, Long] = MMap[Long, Long](),
    var executorPeakMemory: Long = 0,
    var executorAverageMemory: Long = 0,

    // Automatically changed by ConsumerManager before calling map
    var executorStatus: ExecutorStatus.Value = ExecutorStatus.Active
)
{
    def aggregateMetrics: ExecutorEntry =
    {
        totalExecutorBytesRead = this.bytesRead.values.sum
        totalExecutorBytesWritten = this.bytesWritten.values.sum
        totalExecutorRunTime = this.executorRunTime.values.sum
        totalExecutorCpuTime = this.executorCpuTime.values.sum
        if (this.peakMemory.nonEmpty)
            executorPeakMemory = this.peakMemory.values.max
        executorAverageMemory = JobMon.average(this.peakMemory.values)
        this
    }
}


// Mostly used by ELK to perform a cumulative sum
object ExecutorStatus extends Enumeration
{
    val Active = Value(+1)
    val Killed = Value(-1)
}

