package com.socgen.bsc.dpc.jobmon.consumers

import java.text.SimpleDateFormat

import com.socgen.bsc.dpc.jobmon.JobMon
import com.socgen.bsc.dpc.jobmon.entries.{AppEntry, ExecutorEntry, ExecutorStatus, JobEntry, Jsonify}
import io.circe.syntax._
import org.apache.spark.scheduler.{SparkListenerApplicationEnd, SparkListenerExecutorAdded, SparkListenerExecutorRemoved}

import scala.collection.mutable.{Map => MMap}

//region Trait

trait ExecutorConsumer
{
    val name: String

    def triggerOn(executorEntry: ExecutorEntry, executorAdded: SparkListenerExecutorAdded): Unit

    def triggerOn(executorEntry: ExecutorEntry, executorRemoved: SparkListenerExecutorRemoved): Unit
}

//endregion

//region Consumer definition

class ExecutorEntryFiller extends ExecutorConsumer with AppConsumer
{
    val name = "ExecutorEntryFiller"

    def triggerOn(executorEntry: ExecutorEntry, executorAdded: SparkListenerExecutorAdded): Unit =
        None

    def triggerOn(executorEntry: ExecutorEntry, executorRemoved: SparkListenerExecutorRemoved): Unit =
    {
        // Filling info
        executorEntry.executorEndTime = executorRemoved.time
        executorEntry.removedReason = Some(executorRemoved.reason)
        executorEntry.executorStatus = ExecutorStatus.Killed
        executorEntry.aggregateMetrics

        // Sending it to JobMon
        JobMon.addOrUpdateExecutorEntry(executorEntry)
    }

    def triggerOn(appEntry: AppEntry, jobEntries: MMap[Int, JobEntry], executorEntries: MMap[String, ExecutorEntry],
                  appEnd: SparkListenerApplicationEnd): Unit =
    {
        // fetching still active listeners
        val activeExecutors = executorEntries.values.filter(_.executorStatus == ExecutorStatus.Active)

        // Passing them to killed status (Application ending doesnt call onExecutorRemoved)
        activeExecutors.foreach(_.executorStatus = ExecutorStatus.Killed)
        activeExecutors.foreach(_.executorEndTime = appEnd.time)
        activeExecutors.foreach(_.removedReason = Some("Application ended."))

        // Aggregating all metrics and updating entry
        executorEntries.values.map(_.aggregateMetrics).foreach(JobMon.addOrUpdateExecutorEntry)
    }
}

class TinyExecutorPrinter extends ExecutorConsumer
{
    val name = "TinyExecutorPrinter"

    def formatLongTime(time: Long): String =
        new SimpleDateFormat("HH:mm:ss").format(time)

    def triggerOn(executorEntry: ExecutorEntry, executorAdded: SparkListenerExecutorAdded): Unit =
    {
        println(s"[JOBMON][EXEC] Executor ${executorEntry.executorId}"
                    + s" added at ${formatLongTime(executorEntry.executorStartTime)}.\n"
                    + s" ~ Host : ${executorEntry.executorHost}.\n"
                    + s" ~ Cores : ${executorEntry.totalCores}.")
    }

    def triggerOn(executorEntry: ExecutorEntry, executorRemoved: SparkListenerExecutorRemoved): Unit =
    {
        println(s"[JOBMON][EXEC] Executor ${executorEntry.executorId}"
                    + s" removed at ${formatLongTime(executorEntry.executorEndTime)}.\n"
                    + s" ~ Reason : ${executorEntry.removedReason}.")
    }
}

class JsonExecutorPrinter extends ExecutorConsumer
{
    val name = "JsonExecutorPrinter"

    def triggerOn(executorEntry: ExecutorEntry, executorAdded: SparkListenerExecutorAdded): Unit =
    {
        import Jsonify.executorEntryEncoder
        println(s"[JOBMON][EXEC] Writing executor json :\n${executorEntry.asJson}")
    }

    def triggerOn(executorEntry: ExecutorEntry, executorRemoved: SparkListenerExecutorRemoved): Unit =
    {
        import Jsonify.executorEntryEncoder
        println(s"[JOBMON][EXEC] Writing executor json :\n${executorEntry.asJson}")
    }
}

class ExecutorUpdatePublisher extends ExecutorConsumer with AppConsumer
{
    val name = "ExecutorUpdatePublisher"

    def triggerOn(executorEntry: ExecutorEntry, executorAdded: SparkListenerExecutorAdded): Unit =
        JobMon.sendJsonToEs(executorEntry, "executors")

    def triggerOn(executorEntry: ExecutorEntry, executorRemoved: SparkListenerExecutorRemoved): Unit =
        JobMon.sendJsonToEs(executorEntry, "executors")

    def triggerOn(appEntry: AppEntry, jobEntries: MMap[Int, JobEntry], executorEntries: MMap[String, ExecutorEntry],
                  appEnd: SparkListenerApplicationEnd): Unit =
    {
        // fetching still active listeners
        val activeExecutors = executorEntries.values.filter(_.removedReason.contains("Application ended."))

        // Then sending them for Es to update their status
        activeExecutors.map(JobMon.sendJsonToEs(_, "executors"))
    }
}


// TODO : Add more consumers as needed

//endregion



