package com.socgen.bsc.dpc.jobmon.listeners

import com.socgen.bsc.dpc.jobmon.JobMon
import com.socgen.bsc.dpc.jobmon.entries.{EsWrapper, ExecutorEntry, ExecutorStatus, JobEntry}
import org.apache.spark.scheduler._

import scala.collection.mutable.{Buffer => Buff}

/** Calls specific consumer instance in linked JobEntry when a listener triggers */
class ConsumerManager extends SparkListener
{

    //region Trigger handling

    object TriggerManager
    {
        var appStarted: Boolean = false
        var triggerQueue: Buff[() => Unit] = Buff[() => Unit]()

        def addTrigger(trigger: () => Unit): Unit =
        {
            if (appStarted)
                trigger()
            else
                triggerQueue.append(trigger)
        }

        def clearQueue(): Unit =
        {
            appStarted = true
            triggerQueue.foreach(_ ())
        }
    }

    //endregion

    //region Entry Creation

    override def onApplicationStart(appStart: SparkListenerApplicationStart): Unit =
    {
        // Filling app entry
        val appEntry = JobMon.getAppEntry
        appEntry.appName = appStart.appName
        appEntry.appId = appStart.appId.getOrElse("<Unknown>")
        appEntry.appSparkStartTime = appStart.time

        // Sending back to main object
        JobMon.updateAppEntry(appEntry)

        // Filling EsWrapper
        EsWrapper.appName = appEntry.appName
        EsWrapper.appId = appEntry.appId

        // Allowing other listener trigger and calling queue
        TriggerManager.clearQueue()
    }

    override def onJobStart(jobStart: SparkListenerJobStart): Unit =
    {
        // Taken from Spark WebUI source code : Don't ask.
        // src/main/scala/org/apache/spark/status/AppStatusListener.scala
        val queryExecutionId: Long = Option(jobStart.properties)
                                     .flatMap(p => Option(p.getProperty("spark.sql.execution.id"))
                                                   .map(_.toLong))
                                     .getOrElse(-1)

        // Referencing Job to related query if it exists
        if (queryExecutionId != -1)
        {
            val relatedQuery = JobMon.getQueryEntry(queryExecutionId).get
            relatedQuery.queryRelatedJobIds += jobStart.jobId
            JobMon.addOrUpdateQueryEntry(relatedQuery)
        }

        // Creating and registering jobEntry instance
        JobMon.addOrUpdateJobEntry(JobEntry(jobStart.jobId, queryExecutionId, jobStart.time))

        // Filling ID map to register stage ID.
        jobStart.stageIds.foreach(JobMon.setStageToJobId(_, jobStart.jobId))
    }

    override def onExecutorAdded(executorAdded: SparkListenerExecutorAdded): Unit =
    {
        // Creating executor entry
        val executorEntry = ExecutorEntry(executorAdded.executorId,
                                          executorAdded.executorInfo.executorHost,
                                          executorAdded.executorInfo.totalCores,
                                          executorAdded.time)

        // Sending it to JobMon
        JobMon.addOrUpdateExecutorEntry(executorEntry)

        // Then calling consumers
        TriggerManager.addTrigger(() => JobMon.executorConsumers.foreach(_.triggerOn(executorEntry, executorAdded)))
    }

    //endregion

    //region Consumer calling

    override def onTaskEnd(taskEnd: SparkListenerTaskEnd): Unit =
    {
        JobMon.getEntryFromStageId(taskEnd.stageId) -> JobMon.getExecutorEntry(taskEnd.taskInfo.executorId) match
        {
            case (Some(jobEntry), Some(execEntry)) =>
                TriggerManager.addTrigger(() => JobMon.taskConsumers.foreach(_.triggerOn(jobEntry, execEntry, taskEnd)))
            case (None, _)                         =>
                println(s"[JOBMON][TASK][KO] ID ${taskEnd.taskInfo.taskId} not registered in maps.")
            case (_, None)                         =>
                println(s"[JOBMON][EXECUTOR][KO] ID ${taskEnd.taskInfo.executorId} not registered in maps.")
        }
    }

    override def onStageCompleted(stageEnd: SparkListenerStageCompleted): Unit =
    {
        JobMon.getEntryFromStageId(stageEnd.stageInfo.stageId) match
        {
            case Some(entry) =>
                TriggerManager.addTrigger(() => JobMon.stageConsumers.foreach(_.triggerOn(entry, stageEnd)))
            case None        => println(s"[JOBMON][STAGE][KO] ID ${stageEnd.stageInfo.stageId} not registered in maps.")
        }
    }

    override def onJobEnd(jobEnd: SparkListenerJobEnd): Unit =
    {
        // Fetching linked JobEntry.
        JobMon.getEntryFromJobId(jobEnd.jobId) match
        {
            case Some(entry) =>
                TriggerManager.addTrigger(() => JobMon.jobConsumers.foreach(_.triggerOn(entry, jobEnd)))
            case None        => println(s"[JOBMON][JOB][KO] ID ${jobEnd.jobId} not registered in maps.")
        }
    }

    override def onApplicationEnd(appEnd: SparkListenerApplicationEnd): Unit =
    {
        TriggerManager.addTrigger(() => JobMon.appConsumers.foreach(
            _.triggerOn(JobMon.getAppEntry, JobMon.getJobEntries, JobMon.getExecutorEntries, appEnd)))
    }

    override def onExecutorRemoved(executorRemoved: SparkListenerExecutorRemoved): Unit =
    {
        JobMon.getExecutorEntry(executorRemoved.executorId) match
        {
            case Some(entry) =>
                TriggerManager.addTrigger(() => JobMon.executorConsumers.foreach(_.triggerOn(entry, executorRemoved)))
            case None        =>
                println(s"[JOBMON][EXECUTOR][KO] ID ${executorRemoved.executorId} not registered in maps.");
        }
    }

    //endregion
}

