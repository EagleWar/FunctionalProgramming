package com.socgen.bsc.dpc.jobmon.entries

import org.apache.spark.sql.execution.{QueryExecution, SparkPlanInfo}

import scala.collection.mutable.{Buffer => Buff}

/** Register useful information about a Spark Query. */
case class QueryEntry(
    // Query related info
    val queryId: Long,
    var queryExecution: QueryExecution,
    val queryStartTime: Long,

    // Info gotten from SQL START spark listener
    val sparkPlanInfo: SparkPlanInfo,
    val physicalPlanDescription: String,
    val queryDescription: String,
    val queryDetails: String,

    // Related job infos
    var queryRelatedJobIds: Buff[Int] = Buff[Int](),
    var queryRecordsRead: Long = 0,
    var queryRecordsWritten: Long = 0,
    var queryBytesRead: Long = 0,
    var queryBytesWritten: Long = 0,
    var queryExecutorRunTime: Long = 0,
    var queryExecutorCpuTime: Long = 0,
    var queryPeakMemory: Long = 0,
    var queryAverageMemory: Long = 0,

    // Metrics gotten from DriverAccumUpdates
    var queryMetrics: Seq[(Long, Long)] = Seq[(Long, Long)](),

    // Used only for queries that saves tables
    var querySavedTable: Option[QueryEntry.SavedTable] = None,

    // Info gotten from SQL END spark listener
    var queryEndTime: Long = -1,
    var querySuccess: Option[Boolean] = None,
    var queryFailReason: Option[String] = None
)

// Companion object to define inner class
object QueryEntry
{

    case class SavedTable(
        tableName: String,
        database: String,
        tableType: String,
        locationUri: String,
        compressed: String,
        provider: String,
        mode: String,
        outputColumnNames: String,
        numPartitions: String)

}


