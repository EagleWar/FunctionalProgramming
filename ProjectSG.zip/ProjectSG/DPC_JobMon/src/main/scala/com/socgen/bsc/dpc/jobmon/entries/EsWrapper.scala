package com.socgen.bsc.dpc.jobmon.entries


object EsWrapper
{
    var appName: String = "<Unknown>"
    var appId: String = "<Unknown>"
}

sealed trait EsWrapper
{
    val timestamp: Long
    val sourceAppName: String
    val sourceAppId: String
    val dataClass: String
}

case class AppEsWrapper(timestamp: Long,
                        sourceAppName: String,
                        sourceAppId: String,
                        dataClass: String,
                        appEntry: AppEntry) extends EsWrapper

object AppEsWrapper
{
    def apply(appEntry: AppEntry): AppEsWrapper = AppEsWrapper(
        appEntry.appSparkStartTime,
        EsWrapper.appName,
        EsWrapper.appId,
        appEntry.getClass.getSimpleName,
        appEntry)
}

case class QueryEsWrapper(timestamp: Long,
                          sourceAppName: String,
                          sourceAppId: String,
                          dataClass: String,
                          queryEntry: QueryEntry) extends EsWrapper

object QueryEsWrapper
{
    def apply(queryEntry: QueryEntry): QueryEsWrapper = QueryEsWrapper(
        queryEntry.queryStartTime,
        EsWrapper.appName,
        EsWrapper.appId,
        queryEntry.getClass.getSimpleName,
        queryEntry)
}

case class JobEsWrapper(timestamp: Long,
                        sourceAppName: String,
                        sourceAppId: String,
                        dataClass: String,
                        jobEntry: JobEntry) extends EsWrapper

object JobEsWrapper
{
    def apply(jobEntry: JobEntry): JobEsWrapper = JobEsWrapper(
        jobEntry.jobStartTime,
        EsWrapper.appName,
        EsWrapper.appId,
        jobEntry.getClass.getSimpleName,
        jobEntry)
}


case class ExecutorEsWrapper(timestamp: Long,
                             sourceAppName: String,
                             sourceAppId: String,
                             dataClass: String,
                             executorEntry: ExecutorEntry) extends EsWrapper

object ExecutorEsWrapper
{
    def apply(executorEntry: ExecutorEntry): ExecutorEsWrapper = ExecutorEsWrapper(
        if (executorEntry.executorStatus == ExecutorStatus.Active)
            executorEntry.executorStartTime
        else
            executorEntry.executorEndTime,
        EsWrapper.appName,
        EsWrapper.appId,
        executorEntry.getClass.getSimpleName,
        executorEntry)
}
