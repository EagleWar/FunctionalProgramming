package com.socgen.bsc.dpc.jobmon.entries

import org.apache.spark.scheduler.JobResult

import scala.collection.mutable.{Map => MMap}


/** Register useful informations about a Spark job. */
case class JobEntry(
    // Job related info
    val jobId: Int,
    val relatedQueryId: Long,
    val jobStartTime: Long,
    var jobEndTime: Long = -1,
    var jobResult: Option[JobResult] = None,

    // Task related info (map key is task ID)

    val recordsRead: MMap[Long, Long] = MMap[Long, Long](),
    val recordsWritten: MMap[Long, Long] = MMap[Long, Long](),
    var jobRecordsRead: Long = 0,
    var jobRecordsWritten: Long = 0,

    val bytesRead: MMap[Long, Long] = MMap[Long, Long](),
    val bytesWritten: MMap[Long, Long] = MMap[Long, Long](),
    var jobBytesRead: Long = 0,
    var jobBytesWritten: Long = 0,

    val executorRunTime: MMap[Long, Long] = MMap[Long, Long](),
    val executorCpuTime: MMap[Long, Long] = MMap[Long, Long](),
    var jobExecutorRunTime: Long = 0,
    var jobExecutorCpuTime: Long = 0,

    var peakMemory: MMap[Long, Long] = MMap[Long, Long](),
    var jobPeakMemory: Long = 0,
    var jobAverageMemory: Long = 0,

    // Stage related info (map key is stage ID)
    var failedStageReasons: MMap[Int, String] = MMap[Int, String](),
    var jobFailedStage: Int = 0)


