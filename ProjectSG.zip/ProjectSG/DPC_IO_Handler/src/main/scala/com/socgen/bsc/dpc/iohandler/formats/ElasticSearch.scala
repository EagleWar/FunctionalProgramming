package com.socgen.bsc.dpc.iohandler.formats

import com.socgen.bsc.dpc.common.exception.TechnicalException
import com.socgen.bsc.dpc.iohandler.common._
import com.socgen.bsc.dpc.iohandler.input.InputConfiguration
import com.socgen.bsc.dpc.iohandler.output.OutputConfiguration
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.elasticsearch.spark.sql._

/**
 * This object specify the methods to read a DataFrame from an Elastic Search index and to write a DataFrame to an
 * Elastic Search index
 */
object ElasticSearch {


  //region read

  /**
   * This function will read a DataFrame from Elastic Search according to the configuration defined in the
   * InputConfiguration object
   *
   * @param inputConfiguration InputConfiguration which specify the configuration to read the DataFrame from the defined
   *                           Es index
   * @param spark              Implicit Spark Session
   */
  def readFromInputConfig(inputConfiguration: InputConfiguration)
                         (implicit spark: SparkSession): DataFrame = {
    read(options = inputConfiguration.options.getOrElse(Map.empty[String, String]))
  }

  /**
   * This function will read a DataFrame from Elastic Search according to the configuration defined in the map of Strings
   *
   * @param options Map of string which must contain the Elastic Search configuration
   * @param spark   Implicit Spark Session
   */
  def read(options: Map[String, String])(implicit spark: SparkSession): DataFrame = {
    try {
      if (IoCommon.hasMandatoryOptions(options = options, mandatoryOptions = IoCommon.eSMandatoryOptions)) {
        spark.esDF(options(IoCommon.es_resource), options.filterKeys(_ != IoCommon.es_resource))
      } else
        throw TechnicalException(s"A mandatory option is missing among the ${IoCommon.eSMandatoryOptions}. " +
          s"The options are ${IoCommon.displayMapOfStrings(myMap = options)}")
    } catch {
      case e: Exception =>
        throw TechnicalException(s"An error occurred while reading input source with the following configuration " +
          s"${IoCommon.es_resource} : ${options(IoCommon.es_resource)}; ERROR $e")
    }
  }
  //endregion

  //region write

  /**
   * This function will store the DataFrame to Elastic Search according to the configuration defined in the
   * OutpputConfiguration object
   *
   * @param df                  DataFrame to write
   * @param outputConfiguration OutputConfiguration which specify the configuration to save the DataFrame in the defined
   *                            Es index
   * @param mode                Optional - mode to overwrite the mode defined in the OutputConfiguration object
   * @param spark               Implicit Spark Session
   */
  def writeToOutputConfig(df: DataFrame,
                          outputConfiguration: OutputConfiguration,
                          mode: Option[String])
                         (implicit spark: SparkSession): Unit = {
    write(df = df,
      options = outputConfiguration.options.getOrElse(Map.empty[String, String]),
      mode = mode.getOrElse(outputConfiguration.mode))
  }

  /**
   * This function will store the DataFrame to Elastic Search according to the configuration defined in the map of Strings
   *
   * @param df      DataFrame to write
   * @param options Map of String which contains the mandatory elastic search options
   * @param mode    Optional - mode to overwrite the mode defined in the OutputConfiguration object
   * @param spark   Implicit Spark Session
   */
  def write(df: DataFrame,
            options: Map[String, String],
            mode: String)
           (implicit spark: SparkSession): Unit = {
    try {
      if (df.count > 0) {
        if (IoCommon.hasMandatoryOptions(options = options, mandatoryOptions = IoCommon.eSMandatoryOptions)) {
          df.saveToEs(options(IoCommon.es_resource), options.filterKeys(_ != IoCommon.es_resource))
        } else {
          throw TechnicalException(s"A mandatory option is missing among the ${IoCommon.eSMandatoryOptions}. " +
            s"The options are ${IoCommon.displayMapOfStrings(myMap = options)}")
        }
      }
    } catch {
      case e: Exception =>
        throw TechnicalException(s"An error occurred while writing dataframe with the following configuration " +
          s"${IoCommon.es_resource} : ${options(IoCommon.es_resource)}; ERROR $e")
    }
  }
  //endregion

  //region source

  /**
   * This function will return a string that will identify the source as clearly as possible. In this case for Elastic
   * Search, it will return the concatenation of the nodes followed by the index name, sepated by a '|'. Obviously, it's
   * not the best way and it has to be reworked
   *
   * @param options Map of string which must contain the Elastic Search configuration
   * @param spark   Implicit Spark Session
   */
  def getSource(options: Map[String, String])
               (implicit spark: SparkSession): String = {
    try {
      if (IoCommon.hasMandatoryOptions(options = options, mandatoryOptions = IoCommon.eSMandatoryOptions)) {
        s"${options(IoCommon.es_nodes)}|${options(IoCommon.es_resource)}"
      } else
        throw TechnicalException(s"A mandatory option is missing among the ${IoCommon.eSMandatoryOptions}. " +
          s"The options are ${IoCommon.displayMapOfStrings(myMap = options)}")
    } catch {
      case e: Exception =>
        throw TechnicalException(s"An error occurred while reading input source with the following configuration " +
          s"${IoCommon.es_resource} : ${options(IoCommon.es_resource)}; ERROR $e")
    }
  }
  //endregion
}