package com.socgen.bsc.dpc.iohandler.output

import com.socgen.bsc.dpc.common.exception.TechnicalException
import com.socgen.bsc.dpc.iohandler.common.{IoCommon, TypeHandler}
import com.socgen.bsc.dpc.iohandler.dataframe.{Action, DFHandler, QueriesHandler, QueriesOptions}
import com.socgen.bsc.dpc.iohandler.formats._
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * Object which will write a DataFrame to different destinations
 */
object OutputHandler {

  /**
   * This function will save the DataFrame unprocessedDF after applying all the modification to a destination according
   * to the configuration defined in the arguments
   *
   * @param unprocessedDF   DataFrame to write
   * @param partitionFields Set of columns used to partition the DataFrame
   * @param output          Output to identify the output type
   * @param mode            SaveMode - either append or overwrite
   * @param coalesce        Coalesce degree to reduce the number of partitions and reduce the number of output files
   * @param pathDatabase    Path where to store the parquet files composing the hive table
   * @param overwrite       Boolean to specify if it is an overwrite (Spark puts a lock on the table when it read.
   *                        A Table can't be read and rewrite directly, a temporary intermediary table is needed)
   * @param options         Map of string which must contain the options needed to write to the destination
   * @param columnActions   Sequence of Action that will be used to transform the DataFrame
   * @param registerDF      Name of the registered table where the DataFrame (source + columnActions) will be saved
   * @param registerQueries Map of registered queries used to define intermediary DataFrame to get the final one
   * @param hdfs            Hdfs Configuration to read and write on hdfs
   * @param spark           Implicit Spark Session
   */
  def saveDF(unprocessedDF: DataFrame,
             partitionFields: Seq[String] = Seq(),
             output: String,
             mode: String = IoCommon.defaultMode,
             coalesce: Option[Int] = None,
             pathDatabase: String = "",
             overwrite: Boolean = false,
             options: Map[String, String] = Map.empty[String, String],
             columnActions: Option[Seq[Action]],
             registerDF: Option[String],
             registerQueries: Option[Map[String, QueriesOptions]] = None,
             hdfs: FileSystem = FileSystem.get(new Configuration()))
            (implicit spark: SparkSession): Unit = {
    val (outputType, onS3) = TypeHandler.getType(output)
    val processedDF = columnActions match {
      case Some(actions) => DFHandler.processActions(actions = actions, myDataFrame = unprocessedDF)
      case _ => unprocessedDF
    }
    registerDF match {
      case Some(registerDFName) => processedDF.registerTempTable(registerDFName)
      case _ =>
    }
    val df = registerQueries match {
      case Some(registerQueries) => registerQueries foreach {
        registerQuery =>
          QueriesHandler.readQuery(queriesOptions = registerQuery._2, hdfs = hdfs)
            .registerTempTable(registerQuery._1)
      }
        registerQueries.lastOption match {
          case Some(lastRegisteredQuery) => spark.table(lastRegisteredQuery._1)
          case _ => processedDF
        }
      case _ => processedDF
    }
    if (outputType == TypeHandler.CSV_FILE) {
      CsvFile.write(df = df,
        outputPath = output,
        options = options,
        onS3 = onS3,
        hdfs = hdfs)
    } else if (outputType == TypeHandler.JSON_FILE) {
      JsonFile.write(df = df,
        outputPath = output,
        mode = mode,
        coalesce = coalesce,
        options = options,
        onS3 = onS3)
    } else if (outputType == TypeHandler.PARQUET_FILE) {
      ParquetFile.write(df = df,
        outputPath = output,
        mode = mode,
        partitionFields = partitionFields,
        coalesce = coalesce,
        options = options,
        onS3 = onS3)
    } else if (outputType == TypeHandler.HIVE_TABLE) {
      HiveTable.write(df = df,
        outputTable = output,
        pathDatabase = pathDatabase,
        partitionFields = partitionFields,
        overwrite = overwrite,
        mode = mode,
        coalesce = coalesce,
        hdfs = hdfs)
    } else if (outputType == TypeHandler.JDBC_CONF) {
      JdbcConnection.write(df = df,
        mode = mode,
        coalesce = coalesce,
        options = options)
    } else if (outputType == TypeHandler.ES_CONF) {
      ElasticSearch.write(df = df,
        options = options,
        mode = mode)
    } else {
      throw TechnicalException(s"Unrecognized output type argument : $output. Impossible to save the DataFrame. " +
        s"Output must be of type : ${IoCommon.displayListOfStrings(myList = TypeHandler.availableOutput)}")
    }
  }

  /**
   * This function will save the DataFrame unprocessedDF after applying all the modification to a destination according
   * to the defined OutputConfiguration
   *
   * @param unprocessedDF       DataFrame to write
   * @param outputConfiguration OutputConfiguration which specify the configuration to save the DataFrame in the defined 
   * @param overwrite           Boolean to specify if it is an overwrite (Spark puts a lock on the table when it read.
   *                            A Table can't be read and rewrite directly, a temporary intermediary table is needed)
   * @param mode                SaveMode - either append or overwrite
   * @param hdfs                Hdfs Configuration to read and write on hdfs
   * @param spark               Implicit Spark Session
   */
  def saveDFToOutputConfig(unprocessedDF: DataFrame,
                           outputConfiguration: OutputConfiguration,
                           overwrite: Boolean = false,
                           mode: Option[String] = None,
                           hdfs: FileSystem)(implicit spark: SparkSession): Unit = {
    val (outputType, onS3) = TypeHandler.getType(outputConfiguration.destination)
    val processedDF = outputConfiguration.columnActions match {
      case Some(actions) => DFHandler.processActions(actions = actions, myDataFrame = unprocessedDF)
      case _ => unprocessedDF
    }
    outputConfiguration.registerDF match {
      case Some(registerDFName) => processedDF.registerTempTable(registerDFName)
      case _ =>
    }
    val df = outputConfiguration.registerQueries match {
      case Some(registerQueries) => registerQueries foreach {
        registerQuery =>
          QueriesHandler.readQuery(queriesOptions = registerQuery._2, hdfs = hdfs)
            .registerTempTable(registerQuery._1)
      }
        registerQueries.lastOption match {
          case Some(lastRegisteredQuery) => spark.table(lastRegisteredQuery._1)
          case _ => processedDF
        }
      case _ => processedDF
    }

    if (outputType == TypeHandler.CSV_FILE) {
      CsvFile.writeToOutputConfig(df = df,
        outputConfiguration = outputConfiguration,
        onS3 = onS3,
        hdfs = hdfs)
    } else if (outputType == TypeHandler.JSON_FILE) {
      JsonFile.writeToOutputConfig(df = df,
        outputConfiguration = outputConfiguration,
        mode = mode,
        onS3 = onS3)
    } else if (outputType == TypeHandler.PARQUET_FILE) {
      ParquetFile.writeToOutputConfig(df = df,
        outputConfiguration = outputConfiguration,
        mode = mode,
        onS3 = onS3)
    } else if (outputType == TypeHandler.HIVE_TABLE) {
      val overwriteMode = if (!overwrite)
        outputConfiguration.overwrite match {
          case Some(outputConfOverwrite) => outputConfOverwrite
          case _ => false
        }
      else overwrite
      HiveTable.writeToOutputConfig(df = df,
        outputConfiguration = outputConfiguration,
        mode = mode,
        overwrite = overwriteMode,
        hdfs = hdfs)
    } else if (outputType == TypeHandler.JDBC_CONF) {
      JdbcConnection.writeToOutputConfig(df = df,
        outputConfiguration = outputConfiguration,
        mode = mode)
    } else if (outputType == TypeHandler.ES_CONF) {
      ElasticSearch.writeToOutputConfig(df = df,
        outputConfiguration = outputConfiguration,
        mode = mode)
    } else {
      throw TechnicalException(s"Unrecognized output type argument : ${outputConfiguration.destination}. " +
        s"Impossible to get the DataFrame. Output must be of type : " +
        s"${IoCommon.displayListOfStrings(myList = TypeHandler.availableOutput)}")
    }
  }

  /**
   * Thi function will return the destination description according to it's type
   *
   * @param outputConfiguration OutputConfiguration which specify the configuration to save the DataFrame in the defined 
   * @param spark               Implicit Spark Session
   */
  def getDestination(outputConfiguration: OutputConfiguration)
                    (implicit spark: SparkSession): String = {
    val (outputType, _) = TypeHandler.getType(outputConfiguration.destination)
    if (outputType == TypeHandler.CSV_FILE) {
      outputConfiguration.destination
    } else if (outputType == TypeHandler.JSON_FILE) {
      outputConfiguration.destination
    } else if (outputType == TypeHandler.PARQUET_FILE) {
      outputConfiguration.destination
    } else if (outputType == TypeHandler.HIVE_TABLE) {
      outputConfiguration.destination
    } else if (outputType == TypeHandler.JDBC_CONF) {
      JdbcConnection.getSource(options = outputConfiguration.options.getOrElse(Map.empty[String, String]))
    } else {
      throw TechnicalException(s"Unrecognized input type argument : ${outputConfiguration.destination}}. " +
        s"Impossible to get the DataFrame. Input must be of type : " +
        s"${IoCommon.displayListOfStrings(myList = TypeHandler.availableOutput)}")
    }
  }

}
