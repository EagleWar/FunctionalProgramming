package com.socgen.bsc.dpc.iohandler.input

import com.socgen.bsc.dpc.iohandler.dataframe.{Action, QueriesOptions}
/**
 * This case class define the attributes of the InputConfiguration that will be used to read from a source
 *
 * @param source          A String that will be used to identify the type of the source
 * @param options         Map of String that will contains the options used for the source and possibly for S3
 * @param columnActions   Sequence of Action that will be used to transform the DataFrame
 * @param registerDF      Name of the registered table where the DataFrame (source + columnActions) will be saved
 * @param registerQueries Map of registered queries used to define intermediary DataFrame to get the final one
 */
case class InputConfiguration(
                               source: String,
                               options: Option[Map[String, String]],
                               columnActions: Option[Seq[Action]],
                               registerDF: Option[String],
                               registerQueries: Option[Map[String, QueriesOptions]]
                             )