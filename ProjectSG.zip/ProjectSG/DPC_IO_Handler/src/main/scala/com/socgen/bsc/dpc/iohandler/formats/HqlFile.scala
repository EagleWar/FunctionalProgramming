package com.socgen.bsc.dpc.iohandler.formats

import com.socgen.bsc.dpc.common.exception.TechnicalException
import com.socgen.bsc.dpc.iohandler.common.IoCommon
import com.socgen.bsc.dpc.iohandler.input.InputConfiguration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.io.Source

/**
 * This object will create a DataFrame from an sql query stored in a file on HDFS or S3
 */
object HqlFile {

  //region read

  /**
   * This function will create a DataFrame from an sql query stored in a file on HDFS or S3 following the configuration
   * defined in the InputConfiguration object
   *
   * @param inputConfiguration InputConfiguration which specify the configuration to read the DataFrame from the defined
   *                           sql file
   * @param onS3               Boolean to specify in the resource is on S3 or not. Only concern files.
   * @param hdfs               Hdfs Configuration to read and write on hdfs
   * @param spark              Implicit Spark Session
   */
  def readFromInputConfig(inputConfiguration: InputConfiguration,
                          onS3: Boolean,
                          hdfs: FileSystem)
                         (implicit spark: SparkSession): DataFrame = {
    read(inputPath = inputConfiguration.source,
      onS3 = onS3,
      options = inputConfiguration.options.getOrElse(Map.empty[String, String]),
      hdfs = hdfs)
  }

  /**
   * This function will create a DataFrame from an sql query stored in a file on HDFS or S3 following the configuration
   * defined in the arguments
   *
   * @param inputPath Input path where to read the given sql file
   * @param options   Map of string which could contain the options for te S3 connection
   * @param onS3      Boolean to specify in the resource is on S3 or not. Only concern files.
   * @param hdfs      Hdfs Configuration to read and write on hdfs
   * @param spark     Implicit Spark Session
   */
  def read(inputPath: String,
           options: Map[String, String],
           onS3: Boolean,
           hdfs: FileSystem)
          (implicit spark: SparkSession): DataFrame = {
    try {
      val (s3Options, _) = IoCommon.splitMapOption(map = options, regex = IoCommon.s3OptionRegex)
      val sqlQuery = if (onS3) {
        if (IoCommon.hasMandatoryOptions(options = s3Options, mandatoryOptions = IoCommon.s3MandatoryOptions)) {
          s3Options foreach {
            case (key: String, value: String) => spark.sparkContext.hadoopConfiguration.set(key, value)
          }
          val rdd = spark.sparkContext.textFile(inputPath)
          rdd.map(_.replaceAll("^.|.$", "")).reduce(_ + "\n" + _)
        } else
          throw TechnicalException(s"Exception raised while Reading SQL File $inputPath on s3; " +
            s"${IoCommon.displayMapOfStrings(myMap = s3Options)} does not contain the mandatory options : " +
            s"${IoCommon.displayListOfStrings(myList = IoCommon.s3MandatoryOptions)}")
      } else {
        Source.fromInputStream(hdfs.open(new Path(inputPath))).mkString
      }
      spark.sql(sqlQuery)
    } catch {
      case e: Exception =>
        throw TechnicalException(s"An error occurred while reading and executing SQL File : $inputPath ; ERROR: $e")
    }
  }
  //endregion
}