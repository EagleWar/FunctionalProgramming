package com.socgen.bsc.dpc.collect

import scala.collection.mutable.{Map => MMap}

import java.io.{File, FileNotFoundException}
import java.util.Properties
import java.sql.{Connection, DriverManager}

import io.eels.component.jdbc.JdbcSource
import io.eels.component.parquet.{ParquetSink, ParquetWriteOptions}
import org.apache.commons.io.FilenameUtils
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}

import scala.io.Source


class SQLExtractor(connectionProps: Properties, url: String, queriesFolder: String, parquetFolder: String)
{
    val driverGetConn: () => Connection = () => DriverManager.getConnection(url, connectionProps)
    val errorCollection: MMap[String, String] = MMap[String, String]()

    def executeQuery(query: String, outputPath: String)(implicit hadoopConf: Configuration): Path =
    {
        // PostGre being PostGre, we need to use reflection to activate the driver
        Class.forName("org.postgresql.Driver")

        implicit val hadoopFileSystem = FileSystem.get(hadoopConf)
        val parquetFilePath = new Path(outputPath)

        try
        {
            JdbcSource(driverGetConn, query)
            .withFetchSize(SQLExtractor.fetchSize)
            .toDataStream
            .to(ParquetSink(parquetFilePath))
        }
        catch
        {
            case e: Throwable => this.errorCollection += (outputPath -> e.getMessage)
        }

        parquetFilePath
    }

    def executeSqlFile(pathToSql: String)(implicit hadoopConf: Configuration): Path =
    {
        if (!pathToSql.endsWith(".sql"))
            throw new IllegalArgumentException(s"File $pathToSql is not a .sql file.")

        var query = ""
        try
        {
            val sqlFile = Source.fromFile(pathToSql)
            query = sqlFile.mkString
            sqlFile.close
        }
        catch
        {
            case e: FileNotFoundException =>
                throw new FileNotFoundException(s"Could not find SQL file : $pathToSql")
            case e: Throwable             =>
                throw new RuntimeException(s"Unhandled Exception while reading SQL file : ${e.getMessage}")
        }

        val filename = FilenameUtils.getBaseName(pathToSql)
        executeQuery(query, s"$parquetFolder/$filename.parquet")
    }

    def executeSqlFolder(implicit hadoopConf: Configuration): Seq[Path] =
    {
        val dir = new File(queriesFolder)
        if (!dir.exists)
            throw new FileNotFoundException(s"Could not find SQL Directory : $queriesFolder")
        if (!dir.isDirectory)
            throw new IllegalArgumentException(s"Path $queriesFolder is not a directory.")

        dir.listFiles
        .filter(_.isFile)
        .map(_.getAbsolutePath)
        .filter(_.endsWith(".sql"))
        .map(this.executeSqlFile)
    }

    def errorCount: Int =
        this.errorCollection.size

    def errorRecap: String =
        this.errorCollection.map(_.productIterator.mkString(": ")).mkString("\n")
}

object SQLExtractor
{
    // Keys to extract from properties
    val DatabaseUrlKey = "dbUrl"
    val DatabaseTypeKey = "dbType"
    val DatabaseUserKey = "dbUser"
    val DatabasePassKey = "dbPass"
    val QueriesFolderKey = "queriesLoadFolder"
    val ParquetFolderKey = "parquetSaveFolder"

    // Technical config values
    val fetchSize = 100

    // Driver class to instantiate
    def DbTypeToDriverClass(dbType: String): String = dbType match
    {
        // TODO : Add more driver classes
        case "sqlserver"   => "com.microsoft.sqlserver.jdbc.SQLServerDriver"
        case "postgresql"  => "org.postgresql.Driver"
        case other: String => throw new UnsupportedOperationException(
            s"Database type $other is either erroneous or currently unsupported.")
    }

    // Preferred constructor
    def apply(dpcProps: DPCProperties)(implicit hadoopConf: Configuration): SQLExtractor =
    {
        // Fetching keys into properties files

        var dbUrl = dpcProps.get(DatabaseUrlKey)(hadoopConf)
        val queriesFolder = dpcProps.get(QueriesFolderKey)
        val parquetFolder = dpcProps.get(ParquetFolderKey)
        val driverClassName = DbTypeToDriverClass(dpcProps.get(DatabaseTypeKey))

        // Populating connection properties object

        val connectionProps = new Properties()
        connectionProps.put("user", dpcProps.get(DatabaseUserKey)(hadoopConf))
        connectionProps.put("password", dpcProps.get(DatabasePassKey)(hadoopConf))
        connectionProps.put("driver", driverClassName)

        new SQLExtractor(connectionProps, dbUrl, queriesFolder, parquetFolder)
    }
}