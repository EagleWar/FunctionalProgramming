select * from suv_blueprint_framework.blueprint_snapshot
