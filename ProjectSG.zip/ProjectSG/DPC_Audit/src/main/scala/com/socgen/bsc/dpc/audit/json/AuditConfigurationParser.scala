package com.socgen.bsc.dpc.audit.json

import com.socgen.bsc.dpc.iohandler.dataframe.{Action, QueriesOptions}
import com.socgen.bsc.dpc.iohandler.input.InputConfiguration
import com.socgen.bsc.dpc.iohandler.output.OutputConfiguration
import spray.json._

/**
 * This object define the method to read a sequence of AuditConfigurationParser from a Json String
 */
object AuditConfigurationParser extends DefaultJsonProtocol {
  /**
   *
   * @param configs
   */
  case class ArrayAuditConfiguration(configs: Seq[AuditConfiguration])

  /**
   *
   */
  implicit object JsonConfigs extends RootJsonFormat[ArrayAuditConfiguration] {
    /**
     * Json Decoder
     */
    implicit val actionFormat: RootJsonFormat[Action] = jsonFormat7(Action)
    implicit val queriesOptionsFormat: RootJsonFormat[QueriesOptions] = jsonFormat2(QueriesOptions)
    implicit val inputConfigsFormat: RootJsonFormat[InputConfiguration] = jsonFormat5(InputConfiguration)
    implicit val outputConfigsFormat: RootJsonFormat[OutputConfiguration] = jsonFormat9(OutputConfiguration)
    implicit val auditConfigsFormat: RootJsonFormat[AuditConfiguration] = jsonFormat6(AuditConfiguration)

    /**
     *
     * @param value
     * @return
     */
    def read(value: JsValue) = ArrayAuditConfiguration(value.convertTo[List[AuditConfiguration]])

    /**
     *
     * @param obj
     * @return
     */
    def write(obj: ArrayAuditConfiguration) = obj.configs.toJson
  }

  /**
   *
   * @param jsonConfigs
   * @return
   */
  def parseCleanConfigs(jsonConfigs: String): Seq[AuditConfiguration] =
    jsonConfigs.parseJson.convertTo[ArrayAuditConfiguration].configs
}