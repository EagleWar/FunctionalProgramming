package com.socgen.bsc.dpc.audit

import com.socgen.bsc.dpc.audit.common.Common
import com.socgen.bsc.dpc.audit.handlers._
import com.socgen.bsc.dpc.audit.json.AuditConfigurationParser
import com.socgen.bsc.dpc.common.Reporting
import com.socgen.bsc.dpc.common.exception.TechnicalException
import com.socgen.bsc.dpc.common.utility.PropertiesUtility
import com.socgen.bsc.dpc.iohandler.common.IoCommon
import com.socgen.bsc.dpc.iohandler.config.ConfigHandler
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession

/**
 *
 */
object Main {
  /**
   *
   * @param args
   */
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf()
      .setAppName("DPC audit")
      .setIfMissing("master", "local[*]")

    implicit val spark: SparkSession = SparkSession
      .builder
      .config(conf)
      .enableHiveSupport()
      .getOrCreate

    val arguments = Common.parseArguments(Map(), args.toList)
    val auditDate = arguments.get(Common.auditDateArg) match {
      case Some(auditDate) => auditDate
      case _ => throw TechnicalException("auditDate is not defined !")
    }
    val conf_H = new Configuration()
    val hdfs = FileSystem.get(conf_H)
    val reporting = new Reporting("DPC audit")

    val path = new Path(arguments.getOrElse(ConfigHandler.configPathArg, "no_config_path_found"))
    val inputStream = hdfs.open(path)
    val prop = PropertiesUtility.getProperties(inputStream)


    val (updatedJson, _) = ConfigHandler.getFullConf(arguments = arguments,
      prop = prop,
      hdfs = hdfs,
      conf_H = conf_H,
      reporting = reporting)

    AuditConfigurationParser.parseCleanConfigs(updatedJson) foreach {
      config =>
        ConfigurationHandler.generateDiffOutput(configuration = config,
          auditDate = auditDate,
          reporting = reporting,
          hdfs = hdfs)
    }
    spark.stop
  }
}
