package com.socgen.bsc.dpc.audit.handlers

import com.socgen.bsc.dpc.audit.common._
import com.socgen.bsc.dpc.audit.json.AuditConfiguration
import com.socgen.bsc.dpc.common.Reporting
import com.socgen.bsc.dpc.iohandler.input.InputHandler
import com.socgen.bsc.dpc.iohandler.output.OutputHandler
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.sql.SparkSession

/**
 *
 */
object ConfigurationHandler {
  /**
   *
   * @param configuration
   * @param auditDate
   * @param reporting
   * @param hdfs
   * @param spark
   */
  def generateDiffOutput(configuration: AuditConfiguration,
                         auditDate: String,
                         reporting: Reporting,
                         hdfs: FileSystem)(implicit spark: SparkSession): Unit = {
    val leftInput = InputHandler.getSource(inputConfiguration = configuration.leftInput)
    val rightInput = InputHandler.getSource(inputConfiguration = configuration.rightInput)
    val reportOutput = OutputHandler.getDestination(outputConfiguration = configuration.reportOutput)
    configuration.diffOutput match {
      case Some(diffOutputConf) =>
        val diffOutput = OutputHandler.getDestination(outputConfiguration = diffOutputConf)
        Common.checkParameters(leftInput = leftInput,
          rightInput = rightInput,
          reportOutput = reportOutput,
          diffOutput = diffOutput)
      case _ => Common.checkParameters(leftInput = leftInput,
        rightInput = rightInput,
        reportOutput = reportOutput)
    }
    AuditConfigurationProcess.compareDFsAndSaveResults(
      getDfComparison(configuration = configuration, hdfs = hdfs),
      reportOutputConfiguration = configuration.reportOutput,
      diffOutput = configuration.diffOutput,
      auditDate = auditDate,
      hdfs = hdfs,
      reporting = reporting)
  }

  /**
   *
   * @param configuration
   * @param hdfs
   * @param spark
   * @return
   */
  private def getDfComparison(configuration: AuditConfiguration,
                              hdfs: FileSystem)(implicit spark: SparkSession): DataFrameComparison = {
    DataFrameComparison(
      leftDF = InputHandler.getDFFromInputConfig(inputConfiguration = configuration.leftInput,
        hdfs = hdfs),
      leftColumnName = InputHandler.getSource(configuration.leftInput),
      rightDF = InputHandler.getDFFromInputConfig(inputConfiguration = configuration.rightInput,
        hdfs = hdfs),
      rightColumnName = InputHandler.getSource(configuration.rightInput),
      idList = configuration.idList.getOrElse(Seq()),
      dropList = configuration.dropList.getOrElse(Seq())
    )
  }
}