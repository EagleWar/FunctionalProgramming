package com.socgen.bsc.dpcversioning.json

import spray.json._

object ConfigParser extends DefaultJsonProtocol {
  case class ArrayBasicExtractionConfig(configs: Seq[Config])

  implicit object JsonConfigs extends RootJsonFormat[ArrayBasicExtractionConfig] {
    implicit val extractionFormat = jsonFormat2(Config)
    def read(value: JsValue) = ArrayBasicExtractionConfig(value.convertTo[List[Config]])
    def write(obj: ArrayBasicExtractionConfig) = obj.configs.toJson
  }

  def parseBasicExtractionConfigs(jsonConfigs: String): Seq[Config] =
    jsonConfigs.parseJson.convertTo[ArrayBasicExtractionConfig].configs
}
