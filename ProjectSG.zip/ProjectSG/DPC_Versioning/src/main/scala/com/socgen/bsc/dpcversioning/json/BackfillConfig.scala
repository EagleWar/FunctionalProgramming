package com.socgen.bsc.dpcversioning.json

import spray.json._

case class BackfillConfig(tableName: String, coalesce: Option[Int] = None, fieldsToBackfill: String, value: String, toInt: Boolean)

object BackfillConfigParser extends DefaultJsonProtocol {
  case class ArrayBackfillConfig(configs: Seq[BackfillConfig])

  implicit object JsonConfigs extends RootJsonFormat[ArrayBackfillConfig] {
    implicit val backfillFormat: RootJsonFormat[BackfillConfig] = jsonFormat5(BackfillConfig)
    def read(value: JsValue) = ArrayBackfillConfig(value.convertTo[List[BackfillConfig]])
    def write(obj: ArrayBackfillConfig): JsValue = obj.configs.toJson
  }

  def parseBackfillConfigs(jsonConfigs: String): Seq[BackfillConfig] =
    jsonConfigs.parseJson.convertTo[ArrayBackfillConfig].configs
}
