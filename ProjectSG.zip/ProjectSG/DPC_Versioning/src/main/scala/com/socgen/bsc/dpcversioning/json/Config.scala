package com.socgen.bsc.dpcversioning.json

case class Config(tableName: String, coalesce: Option[Int] = None)
