package com.socgen.bsc.dpc.tablemanager.common

import com.socgen.bsc.dpc.common.logger.ContentToJson._
import com.socgen.bsc.dpc.common.logger.Message
import com.socgen.bsc.dpc.iohandler.common.IoCommon
import com.socgen.bsc.dpc.iohandler.config.ConfigHandler
import com.socgen.bsc.dpc.iohandler.dataframe.DFHandler
import com.socgen.bsc.dpc.iohandler.input.InputHandler
import com.socgen.bsc.dpc.iohandler.output.OutputHandler
import com.socgen.bsc.dpc.tablemanager.json._
import com.socgen.sdt.logging.loggers.impl.DataLoggerFactory
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.sql.SparkSession
import org.slf4j.Logger

import scala.annotation.tailrec

object Common {
  lazy val log: Logger = DataLoggerFactory.getLogger("tablemanager.common.Common")

  /**
   * This function will extract the arguments value and build a Key Value Map
   *
   * @param map  Map initiated to empty that will be recursively fed with the arguments and their value
   * @param list List of the arguments with the key followed by their associated value
   * @return
   */
  @tailrec
  def parseArguments(map: Map[String, String] = Map(), list: List[String]): Map[String, String] = {
    list match {
      case Nil => map
      // JSON CONFIGS FILE (multiple execution)
      case ("--config-path" | "-cp") :: path :: tail =>
        parseArguments(map ++ Map(ConfigHandler.configPathArg -> path), tail)
      case ("--filename" | "-f") :: filename :: tail =>
        parseArguments(map ++ Map(ConfigHandler.fileNamePathArg -> filename), tail)
      case ("--on-S3" | "-s3") :: isS3 :: tail =>
        parseArguments(map ++ Map(ConfigHandler.isS3 -> isS3), tail)
      case unknown :: tail =>
        log.info(Message(s"unknown arguments $unknown"))
        parseArguments(map, tail)
    }
  }

  /**
   * This function will take a TableManagerConfiguration, read the source and write it to the defined outputs
   *
   * @param formatterConfig A TableManagerConfiguration which define the source and the outputs
   * @param hdfs            HDFS Connection
   * @param spark           Implicit Spark Session
   */
  def writeOutputs(formatterConfig: TableManagerConfiguration, hdfs: FileSystem)(implicit spark: SparkSession): Unit = {
    val inputConfiguration = formatterConfig.input
    val outputConfigurations = formatterConfig.outputs
    val inputDF = DFHandler.lowerColumns(InputHandler.getDFFromInputConfig(inputConfiguration = inputConfiguration, hdfs = hdfs))

    outputConfigurations foreach {
      outputConfiguration =>
        val overwrite = IoCommon.areSourcesEqual(inputConfiguration = inputConfiguration, outputConfiguration = outputConfiguration)
        OutputHandler.saveDFToOutputConfig(unprocessedDF = inputDF, outputConfiguration = outputConfiguration, overwrite = overwrite, hdfs = hdfs)
    }
  }
}