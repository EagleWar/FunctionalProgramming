package com.socgen.bsc.dpc.iohandler.formats

import com.socgen.bsc.dpc.common.exception.TechnicalException
import com.socgen.bsc.dpc.iohandler.common.IoCommon
import com.socgen.bsc.dpc.iohandler.input.InputConfiguration
import com.socgen.bsc.dpc.iohandler.output.OutputConfiguration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.io.Source

/**
 * This object read a DataFrame from json file and can write a DataFrame to a json file
 */
object JsonFile {

  //region read

  /**
   * This function read a json config file as String and not as a DataFrame
   *
   * @param inputPath Input path where to read the given json file
   * @param options   Map of string which must contain the options for s3 when the file is on s3
   * @param onS3      boolean to specify in the resource is on S3 or not. Only concern files.
   * @param hdfs      Hdfs Configuration to read and write on hdfs
   * @param spark     Implicit Spark Session
   */
  def readConfiguration(inputPath: String,
                        options: Map[String, String],
                        onS3: Boolean,
                        hdfs: FileSystem)
                       (implicit spark: SparkSession): String = {
    try {
      if (onS3) {
        val (s3Options, _) = IoCommon.splitMapOption(map = options, regex = IoCommon.s3OptionRegex)
        if (IoCommon.hasMandatoryOptions(options = s3Options, mandatoryOptions = IoCommon.s3MandatoryOptions)) {
          s3Options foreach {
            case (key: String, value: String) => spark.sparkContext.hadoopConfiguration.set(key, value)
          }
          val rdd = spark.sparkContext.textFile(inputPath)
          rdd.map(_.replaceAll("^.|.$", "")).reduce(_ + "\n" + _).mkString
        } else {
          throw TechnicalException(s"Exception raised while Reading Json File $inputPath on s3; " +
            s"${IoCommon.displayMapOfStrings(myMap = s3Options)} does not contain the mandatory options : " +
            s"${IoCommon.displayListOfStrings(myList = IoCommon.s3MandatoryOptions)}")
        }
      } else {
        val path = new Path(s"$inputPath")
        val inputStream = hdfs.open(path)
        Source.fromInputStream(inputStream).mkString
      }
    } catch {
      case e: Exception => throw TechnicalException(s"An error occurred while reading Json File : $inputPath ; ERROR: $e")
    }
  }

  /**
   * This function will read the DataFrame from a json file according to the inputConfiguration
   *
   * @param inputConfiguration InputConfiguration which specify the configuration to read the DataFrame from the defined
   *                           json file
   * @param onS3               boolean to specify in the resource is on S3 or not. Only concern files.
   * @param spark              Implicit Spark Session
   */
  def readFromInputConfig(inputConfiguration: InputConfiguration, onS3: Boolean)(implicit spark: SparkSession): DataFrame = {
    read(inputPath = inputConfiguration.source, onS3 = onS3, options = inputConfiguration.options.getOrElse(Map.empty[String, String]))
  }

  /**
   * This function will read the DataFrame from a json file
   *
   * @param inputPath Input path where to read the given json file
   * @param options   Map of string which contain the information for the s3 connection
   * @param onS3      boolean to specify in the resource is on S3 or not. Only concern files.
   * @param spark     Implicit Spark Session
   */
  def read(inputPath: String, options: Map[String, String], onS3: Boolean)(implicit spark: SparkSession): DataFrame = {
    try {
      val (s3Options, _) = IoCommon.splitMapOption(map = options, regex = IoCommon.s3OptionRegex)
      if (onS3) {
        if (IoCommon.hasMandatoryOptions(options = s3Options, mandatoryOptions = IoCommon.s3MandatoryOptions)) {
          s3Options foreach {
            case (key: String, value: String) => spark.sparkContext.hadoopConfiguration.set(key, value)
          }
        } else
          throw TechnicalException(s"Exception raised while Reading Json File $inputPath on s3; " +
            s"${IoCommon.displayMapOfStrings(myMap = s3Options)} does not contain the mandatory options : " +
            s"${IoCommon.displayListOfStrings(myList = IoCommon.s3MandatoryOptions)}")
      }
      spark.read.json(inputPath)
    } catch {
      case e: Exception => throw TechnicalException(s"An error occurred while reading Json File : $inputPath ; ERROR: $e")
    }
  }
  //endregion

  //region write

  /**
   * This function will store the DataFrame to a Json file according to the configuration defined in the OutputConfiguration object
   *
   * @param df                  DataFrame to write
   * @param outputConfiguration OutputConfiguration which specify the configuration to save the DataFrame to the defined json file
   * @param mode                SaveMode either append or overwrite
   * @param onS3                boolean to specify in the resource is on S3 or not. Only concern files.
   * @param spark               Implicit Spark Session
   */
  def writeToOutputConfig(df: DataFrame, outputConfiguration: OutputConfiguration, mode: Option[String], onS3: Boolean)(implicit spark: SparkSession): Unit = {
    write(df = df,
      outputPath = outputConfiguration.destination,
      mode = mode.getOrElse(outputConfiguration.mode),
      coalesce = outputConfiguration.coalesce,
      options = outputConfiguration.options.getOrElse(Map.empty[String, String]),
      onS3 = onS3)
  }

  /**
   * This function will store the DataFrame to a Json file according to the configuration
   *
   * @param df         DataFrame to write
   * @param outputPath Output path where to store the json file
   * @param mode       Save mode : append or overwrite
   * @param coalesce   Coalesce degree to reduce the number of partitions and reduce the number of output files
   * @param options    Map which contains the information for the s3 connection
   * @param onS3       Boolean to specify if the json will be saved on S3 or not
   * @param spark      Implicit Spark Session
   */
  def write(df: DataFrame, outputPath: String, mode: String, coalesce: Option[Int] = None, options: Map[String, String], onS3: Boolean)(implicit spark: SparkSession): Unit = {
    try {
      val (s3Options, _) = IoCommon.splitMapOption(map = options, regex = IoCommon.s3OptionRegex)
      if (onS3) {
        if (IoCommon.hasMandatoryOptions(options = s3Options, mandatoryOptions = IoCommon.s3MandatoryOptions))
          s3Options foreach {
            case (key: String, value: String) => spark.sparkContext.hadoopConfiguration.set(key, value)
          }
        else
          throw TechnicalException(s"Exception raised while Writing Json File on s3; " +
            s"${IoCommon.displayMapOfStrings(myMap = s3Options)} does not contain the mandatory options : " +
            s"${IoCommon.displayListOfStrings(myList = IoCommon.s3MandatoryOptions)}")
      }
      val saveMode = IoCommon.getSaveMode(mode = mode)
      df.coalesce(coalesce.getOrElse(1)).write.mode(saveMode).json(s"$outputPath")
    } catch {
      case e: Exception =>
        throw TechnicalException(s"An error occurred while writing Json File : $outputPath ; ERROR: $e")
    }
  }
  //endregion
}