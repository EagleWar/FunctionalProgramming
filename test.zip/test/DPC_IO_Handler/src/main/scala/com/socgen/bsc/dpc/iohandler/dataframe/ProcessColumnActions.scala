package com.socgen.bsc.dpc.iohandler.dataframe

import com.socgen.bsc.dpc.common.exception.TechnicalException
import com.socgen.sdt.logging.loggers.impl.DataLoggerFactory
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.slf4j.Logger

import scala.annotation.tailrec

object ProcessColumnActions {
  // ACTIONS
  private final val addColumnAction = "ADD"
  private final val deleteColumnAction = "DELETE"
  private final val renameColumnAction = "RENAME"
  private final val castColumnAction = "CAST"
  private final val filterColumnAction = "FILTER"
  private final val filterExpressionColumnAction = "FILTER_EXPR"
  private final val trimColumnAction = "TRIM"
  private final val upperColumnAction = "UPPER"
  private final val lowerColumnAction = "LOWER"

  lazy val log: Logger = DataLoggerFactory.getLogger("tablemanager.common.ProcessColumnActions")

  /**
   * This functions will apply recursively a sequence of actions to a DataFrame
   *
   * @param actions Sequence of actions to apply to the DataFrame
   * @param df      Dataframe to change
   * @return
   */
  @tailrec
  def runActionsRec(actions: Seq[Action],
                    df: DataFrame): DataFrame = {
    if (actions.isEmpty)
      df
    else
      runActionsRec(actions.tail,
        df.transform(runAction(actions.head)))
  }

  /**
   * This functions will apply a sequence of actions to a DataFrame using an accumulator
   *
   * @param actions Sequence of actions to apply to the DataFrame
   * @param df      Dataframe to change
   * @return
   */
  def runActionsAcc(actions: Seq[Action],
                    df: DataFrame): DataFrame = {
    if (actions.isEmpty) df
    else
      actions.foldLeft(df) {
        (acc, action) => acc.transform(runAction(action))
      }
  }

  /**
   * This function will identify and apply an action to a DataFrame
   *
   * @param action Action object containing the mandatory information to identify and apply the action
   * @return
   */
  private def runAction(action: Action): DataFrame => DataFrame = {
    df =>
      if (action.actionType == addColumnAction) {
        getDFforAddAction(df = df, newColumn = action.newColumn, newColumnType = action.newColumnType, defaultValue = action.value)
      } else if (action.actionType == deleteColumnAction) {
        getDFForDeleteAction(df = df, column = action.column)
      } else if (action.actionType == renameColumnAction) {
        getDFForRenameAction(df = df, column = action.column, newColumn = action.newColumn)
      } else if (action.actionType == castColumnAction) {
        getDFForCastAction(df = df, column = action.column, newColumnType = action.newColumnType)
      } else if (action.actionType == filterColumnAction) {
        getDFForFilterAction(df = df, column = action.column, filterValue = action.value, comparison = action.comparison)
      } else if (action.actionType == filterExpressionColumnAction) {
        getDFForFilterExpressionAction(df = df, filterExpression = action.filterExpression)
      } else if (action.actionType == trimColumnAction) {
        getDFForTrimAction(df = df, column = action.column)
      } else if (action.actionType == lowerColumnAction) {
        getDFForLowerAction(df = df, column = action.column)
      } else if (action.actionType == upperColumnAction) {
        getDFForUpperAction(df = df, column = action.column)
      } else {
        throw TechnicalException(s"Unsupported action type : ${action.actionType}")
      }
  }

  /**
   * This function will rename a column on the DataFrame
   *
   * @param df        DataFrame on which the rename action will be applied
   * @param column    Column which will be renamed
   * @param newColumn New name of the column
   * @return
   */
  private def getDFForRenameAction(df: DataFrame,
                                   column: Option[String],
                                   newColumn: Option[String]): DataFrame = {
    column match {
      case Some(columnToDelete) if columnToDelete.trim != "" && !columnToDelete.contains('.') =>
        val columns = df.columns.map(_.toLowerCase)
        if (columns contains columnToDelete.toLowerCase)
          newColumn match {
            case Some(columnToAdd) if columnToAdd.trim != "" && !columnToAdd.contains('.') =>
              df.withColumnRenamed(columnToDelete.toLowerCase, columnToAdd.toLowerCase)
            case Some(columnToAdd) if columnToAdd.trim == "" || columnToAdd.contains('.') =>
              throw TechnicalException(s"Non valid new column name : $columnToAdd, column can not be renamed")
            case _ =>
              throw TechnicalException(s"Undefined new column name, column can not be renamed")
          }
        else
          throw TechnicalException(s"Columns to delete ($columnToDelete) " +
            s"is not a member of given input columns : [${columns.mkString(";")}]")
      case Some(columnToDelete) if columnToDelete.trim == "" || columnToDelete.contains('.') =>
        throw TechnicalException(s"Non valid column name : $columnToDelete, column can not be renamed")
      case _ =>
        throw TechnicalException(s"Undefined column name, column can not be renamed")
    }
  }

  /**
   * This function will remove the column on the DataFrame
   *
   * @param df     DataFrame on which the delete action will be applied
   * @param column The column which will be deleted
   * @return
   */
  private def getDFForDeleteAction(df: DataFrame,
                                   column: Option[String]): DataFrame = {
    column match {
      case Some(columnToDelete) if columnToDelete.trim != "" && !columnToDelete.contains('.') =>
        val columns = df.columns.map(_.toLowerCase)
        if (columns contains columnToDelete.toLowerCase)
          df.drop(columnToDelete.toLowerCase)
        else
          throw TechnicalException(s"Columns to delete ($columnToDelete) " +
            s"is not a member of given input columns : [${columns.mkString(";")}]")
      case Some(columnToDelete) if columnToDelete.trim == "" || columnToDelete.contains('.') =>
        throw TechnicalException(s"Non valid column name : $columnToDelete, column can not be deleted")
      case _ =>
        throw TechnicalException(s"Undefined column name, column can not be deleted")
    }
  }

  /**
   * This function will add a column on the DataFrame with a specified type and a possible default value
   *
   * @param df            DataFrame on which the add action will be applied
   * @param newColumn     Column to be added to the DataFrame
   * @param newColumnType Type of the column that will be added
   * @param defaultValue  Optional - Default value
   * @return
   */
  private def getDFforAddAction(df: DataFrame,
                                newColumn: Option[String],
                                newColumnType: Option[String],
                                defaultValue: Option[String]): DataFrame = {
    newColumn match {
      case Some(columnToAdd) if columnToAdd.trim != "" && !columnToAdd.contains('.') =>
        newColumnType match {
          case Some(columnTypeToAdd) =>
            val dataType = DFHandler.getDataType(columnTypeToAdd)
            df.withColumn(columnToAdd.toLowerCase, lit(defaultValue.getOrElse("")).cast(dataType))
          case _ => throw TechnicalException(s"Undefined column type for new column : $columnToAdd, column can not be added")
        }
      case Some(columnToAdd) if columnToAdd.trim == "" || columnToAdd.contains('.') =>
        throw TechnicalException(s"Non valid new column name : $columnToAdd, column can not be added")
      case _ =>
        throw TechnicalException(s"Undefined new column name, column can not be added")

    }
  }

  /**
   * This function will cast a column of the DataFrame
   *
   * @param df            DataFrame on which the cast action will be applied
   * @param column        Column to cast
   * @param newColumnType New type of the column
   * @return
   */
  private def getDFForCastAction(df: DataFrame,
                                 column: Option[String],
                                 newColumnType: Option[String]): DataFrame = {
    column match {
      case Some(columnToCast) if columnToCast.trim != "" && !columnToCast.contains('.') =>
        val columns = df.columns.map(_.toLowerCase)
        if (columns contains columnToCast.toLowerCase)
          newColumnType match {
            case Some(castType) => val dataType = DFHandler.getDataType(castType)
              try {
                df.withColumn(columnToCast, col(columnToCast).cast(dataType))
              } catch {
                case e: Exception => throw TechnicalException(s"Columns ($columnToCast) can't be casted to $dataType; Error $e")
              }
            case _ => throw TechnicalException(s"Columns ($columnToCast) can't be casted because new type is not specified")
          }
        else
          throw TechnicalException(s"Columns to cast ($columnToCast) is not a member of given input columns : [${columns.mkString(";")}]")
      case Some(columnToCast) if columnToCast.trim == "" || columnToCast.contains('.') =>
        throw TechnicalException(s"Non valid column name : $columnToCast, column can not be casted")
      case _ =>
        throw TechnicalException(s"Undefined column name, column can not be casted")
    }
  }

  /**
   * This function will filter on a column of a DataFrame
   *
   * @param df          DataFrame on which the filter action will be applied
   * @param column      The column on which which will be aplied
   * @param filterValue The value used to compare
   * @param comparison  The comparison applied : equal, gt, gte, lt, lte, different, mandatory
   * @return
   */
  private def getDFForFilterAction(df: DataFrame,
                                   column: Option[String],
                                   filterValue: Option[String],
                                   comparison: Option[String]): DataFrame = {
    column match {
      case Some(columnToFilter) if columnToFilter.trim != "" && !columnToFilter.contains('.') =>
        val columns = df.columns.map(_.toLowerCase)
        if (columns contains columnToFilter.toLowerCase)
          filterValue match {
            case Some(filteringValue) =>
              comparison match {
                case Some(operator) => if (operator == "==" || operator == "equal") {
                  try {
                    df.filter(col(columnToFilter) === filteringValue)
                  } catch {
                    case e: Exception =>
                      throw TechnicalException(s"Columns ($columnToFilter) can't be filtered by '$filteringValue'; Error $e")
                  }
                } else if (operator == ">" || operator == "gt") {
                  try {
                    df.filter(col(columnToFilter) > filteringValue)
                  } catch {
                    case e: Exception =>
                      throw TechnicalException(s"Columns ($columnToFilter) can't be filtered by '$filteringValue'; Error $e")
                  }
                } else if (operator == ">=" || operator == "gte") {
                  try {
                    df.filter(col(columnToFilter) >= filteringValue)
                  } catch {
                    case e: Exception =>
                      throw TechnicalException(s"Columns ($columnToFilter) can't be filtered by '$filteringValue'; Error $e")
                  }
                } else if (operator == "<" || operator == "lt") {
                  try {
                    df.filter(col(columnToFilter) < filteringValue)
                  } catch {
                    case e: Exception =>
                      throw TechnicalException(s"Columns ($columnToFilter) can't be filtered by '$filteringValue'; Error $e")
                  }
                } else if (operator == "<=" || operator == "lte") {
                  try {
                    df.filter(col(columnToFilter) <= filteringValue)
                  } catch {
                    case e: Exception =>
                      throw TechnicalException(s"Columns ($columnToFilter) can't be filtered by '$filteringValue'; Error $e")
                  }
                } else if (operator == "!=" || operator == "different") {
                  try {
                    df.filter(col(columnToFilter) =!= filteringValue)
                  } catch {
                    case e: Exception =>
                      throw TechnicalException(s"Columns ($columnToFilter) can't be filtered by '$filteringValue'; Error $e")
                  }
                } else {
                  throw TechnicalException(s"Columns ($columnToFilter) can't be filtered by '$filteringValue'; Unrecognized operator $operator")
                }
                case _ => try {
                  df.filter(col(columnToFilter) === filteringValue)
                } catch {
                  case e: Exception =>
                    throw TechnicalException(s"Columns ($columnToFilter) can't be filtered by '$filteringValue'; Error $e")
                }
              }
            case _ =>
              //noinspection ScalaUnnecessaryParentheses
              comparison match {
                case Some(operator) if (operator == "mandatory") =>
                  df.filter(col(columnToFilter).isNotNull)
                case _ =>
                  throw TechnicalException(s"Columns ($columnToFilter) can't be filtered because value to filter is not specified")
              }
          }
        else
          throw TechnicalException(s"Columns to filter ($columnToFilter) is not a member of given input columns : [${columns.mkString(";")}]")
      case Some(columnToFilter) if columnToFilter.trim == "" || columnToFilter.contains('.') =>
        throw TechnicalException(s"Non valid column name : $columnToFilter, column can not be filtered")
      case _ => throw TechnicalException(s"Undefined column name, column can not be filtered")
    }
  }

  /**
   * This function will apply a filter expression on the Dataframe
   *
   * @param df               DataFrame on which the filter action will be applied
   * @param filterExpression The filter expression to use
   * @return
   */
  private def getDFForFilterExpressionAction(df: DataFrame, filterExpression: Option[String]): DataFrame = {
    filterExpression match {
      case Some(expression) => try {
        df.filter(expression)
      } catch {
        case e: Exception => throw TechnicalException(s"DataFrame can't be filtered by `$expression`; Error $e")
      }
      case _ => throw TechnicalException(s"Undefined filterExpression, dataframe can not be filtered")
    }
  }

  /**
   * This function will lower the values of the specified column of the DataFrame
   *
   * @param df     DataFrame on which the lower action will be applied
   * @param column The column on which the values will be lowered
   * @return
   */
  private def getDFForLowerAction(df: DataFrame, column: Option[String]): DataFrame = {
    column match {
      case Some(columnToLower) if columnToLower.trim != "" && !columnToLower.contains('.') =>
        changeCaseColumn(df = df, columnName = columnToLower)
      case _ => throw TechnicalException(s"Undefined column name, column can not be lowered")
    }
  }

  /**
   * This function will either lower or upper the values of a column in a DataFrame
   *
   * @param df         DataFrame on which the lower or upper action will be applied
   * @param columnName Column on which the values will be either lowered or uppered case
   * @param toLower    If set to true the values will be lowered else uppered, default value is true
   * @return
   */
  private def changeCaseColumn(df: DataFrame, columnName: String, toLower: Boolean = true): DataFrame = {
    if (toLower)
      df.withColumn(columnName, lower(col(columnName)))
    else
      df.withColumn(columnName, upper(col(columnName)))
  }

  /**
   * This function will upper the values of the specified column of the DataFrame
   *
   * @param df     DataFrame on which the upper action will be applied
   * @param column The column on which the values will be uppered
   * @return
   */
  private def getDFForUpperAction(df: DataFrame, column: Option[String]): DataFrame = {
    column match {
      case Some(columnToUpper) if columnToUpper.trim != "" && !columnToUpper.contains('.') =>
        changeCaseColumn(df = df, columnName = columnToUpper, toLower = false)
      case _ => throw TechnicalException(s"Undefined column name, column can not be uppered")
    }
  }

  /**
   * This function will trim the values of the specified column of the DataFrame
   *
   * @param df     DataFrame on which the trim action will be applied
   * @param column The column on which the values will be trimmed
   * @return
   */
  private def getDFForTrimAction(df: DataFrame, column: Option[String]): DataFrame = {
    column match {
      case Some(columnToTrim) if columnToTrim.trim != "" && !columnToTrim.contains('.') =>
        df.withColumn(columnToTrim, trim(col(columnToTrim)));
      case _ => throw TechnicalException(s"Undefined column name, column can not be trimmed")
    }
  }
}
