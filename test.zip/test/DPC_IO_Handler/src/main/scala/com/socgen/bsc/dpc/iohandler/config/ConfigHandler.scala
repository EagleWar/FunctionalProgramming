package com.socgen.bsc.dpc.iohandler.config

import com.socgen.bsc.dpc.common.Reporting
import com.socgen.bsc.dpc.common.exception.TechnicalException
import com.socgen.bsc.dpc.common.utility.{PasswordHandler, PropertiesUtility}
import com.socgen.bsc.dpc.iohandler.common.IoCommon
import com.socgen.bsc.dpc.iohandler.input.InputHandler
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.security.alias.CredentialProviderFactory
import org.apache.spark.sql.SparkSession

import scala.collection.mutable.{Map => MMap}

object ConfigHandler {
  // Properties
  /**
   * Program arguments && Properties
   */
  final val fileNamePathArg = "fileName"
  final val configPathArg = "configPath"

  private val jceksConfigPath = "jceksPath"
  private val passwordsConfig = "passwords"
  private val defaultPasswordSeparatorValue = ";"
  private val passwordConfigSeparator = "passwordSeparator"
  private val hdfsAuthorizedConfigPath = "hdfsAuthorizedPath"
  private val s3AuthorizedConfigPath = "s3AuthorizedPath"

  val mandatoryProperties = Seq(hdfsAuthorizedConfigPath, s3AuthorizedConfigPath)

  /**
   * Config File
   */
  final val isS3 = "isS3"

  /**
   * This function will write the mandatory properties to the CR
   *
   * @param prop      Map of String which contains the properties of the program
   * @param reporting Reporting used to write the logs
   */
  private def addMandatoryPropertiesToReporting(prop: MMap[String, String],
                                                reporting: Reporting): Unit =
    PropertiesUtility.addMandatoryPropertiesToReporting(mandatoryProperties, reporting, prop)

  /**
   * This function will extract the passwords from the jceks file
   *
   * @param prop   Map of String which contains the properties of the program
   * @param conf_H HDFS Connection
   * @param spark  Implicit Spark Session
   * @return
   */
  private def getPasswords(prop: Map[String, String],
                           conf_H: Configuration)
                          (implicit spark: SparkSession): Map[String, String] =
    prop.get(jceksConfigPath) match {
      case Some(jceksPath) =>
        conf_H.set(CredentialProviderFactory.CREDENTIAL_PROVIDER_PATH, jceksPath)
        val configPasswords = prop.getOrElse(passwordsConfig, "")
          .split(prop.getOrElse(passwordConfigSeparator, defaultPasswordSeparatorValue))
        PasswordHandler.extractPasswords(configPasswords, hadoopConf = conf_H)
      case _ => Map[String, String]()
    }

  /**
   *
   * @param arguments Map of String which contains the arguments of the program
   * @param prop      Map of String which contains the properties of the program
   * @param passwords Map of String which contains the password keys with their value extracted from the jecks file
   * @param hdfs      HDFS FileSystem connection
   * @param spark     Implicit Spark Session
   * @return
   */
  private def getJsonConfigFile(arguments: Map[String, String],
                                prop: Map[String, String],
                                passwords: Map[String, String],
                                hdfs: FileSystem)
                               (implicit spark: SparkSession): String =
    arguments.get(fileNamePathArg) match {
      case Some(fileName) =>
        val isOnS3 = arguments.get(isS3) match {
          case Some(isMaybeOn3) => isMaybeOn3.toLowerCase == "true" || isMaybeOn3.toLowerCase == "yes"
          case _ => false
        }
        getJsonConfig(fileName = fileName, prop = prop, passwords = passwords, isOnS3 = isOnS3, hdfs = hdfs)
      case _ => throw new IllegalArgumentException(s"No Json config path option")
    }

  /**
   * This function will replace the password by their value using the KV Map of the passwords
   *
   * @param jsonFile  String to be updated
   * @param passwords Map of the password keys and their value extracted from the jceks file
   * @param spark     Implicit Spark Session
   * @return
   */
  private def getUpdatedConfigFile(jsonFile: String, passwords: Map[String, String])
                                  (implicit spark: SparkSession): String = {
    PasswordHandler.replacePasswords(
      myString = jsonFile,
      passwords = passwords)
  }

  /**
   * This function will read the Json file either from hdfs or from S3
   *
   * @param fileName  Name of the json config
   * @param prop      Map of String which contains the properties of the program
   * @param passwords Map of String which contains the password keys with their value extracted from the jecks file
   * @param isOnS3    Boolean to indicate if the config file is on S3
   * @param hdfs      HDFS FileSystem
   * @param spark     Implicit Spark Sessions
   * @return
   */
  private def getJsonConfig(fileName: String,
                            prop: Map[String, String],
                            passwords: Map[String, String],
                            isOnS3: Boolean,
                            hdfs: FileSystem)
                           (implicit spark: SparkSession): String = {
    if (isOnS3) {
      prop.get(s3AuthorizedConfigPath) match {
        case Some(s3AuthorizedPath) => val updatedProperties = getS3Config(properties = prop,
          passwords = passwords)
          InputHandler.getStringFromFile(basePath = s3AuthorizedPath,
            fileName = fileName,
            options = Some(updatedProperties),
            hdfs = hdfs)
        case _ => throw TechnicalException(s"Missing Properties option : $s3AuthorizedConfigPath")
      }
    } else {
      prop.get(hdfsAuthorizedConfigPath) match {
        case Some(hdfsAuthorizedPath) =>
          InputHandler.getStringFromFile(basePath = hdfsAuthorizedPath,
            fileName = fileName,
            options = None,
            hdfs = hdfs)
        case _ => throw TechnicalException(s"Missing Properties option : $hdfsAuthorizedConfigPath")
      }
    }
  }

  /**
   * This function will get the S3 configuration by using the Jceks and the S3 configuration
   *
   * @param properties Map of String which contains the properties of the program
   * @param passwords  Map of String which contains the password keys and their value extracted from the jckes file
   * @param spark      Implicit Spark Session
   * @return
   */
  private def getS3Config(properties: Map[String, String],
                          passwords: Map[String, String])
                         (implicit spark: SparkSession): Map[String, String] = {
    if (IoCommon.hasMandatoryOptions(options = properties ++ passwords, mandatoryOptions = IoCommon.s3MandatoryOptions)) {
      val endpointOption = properties.get(IoCommon.endpointOption) match {
        case Some(existingOption) => existingOption
        case _ => throw TechnicalException (s"Missing argument for S3 connection : ${IoCommon.endpointOption} " +
          s"in the properties : ${IoCommon.displayMapOfStrings(properties)}")
      }
      val secretKeyOption = passwords.get(IoCommon.secretKeyOption) match {
        case Some(existingOption) => existingOption
        case _ => throw TechnicalException (s"Missing argument for S3 connection : ${IoCommon.secretKeyOption} " +
          s"in the passwords : ${IoCommon.displayMapOfStrings(passwords)}")
      }
      val accessKeyOption = passwords.get(IoCommon.accessKeyOption) match {
        case Some(existingOption) => existingOption
        case _ => throw TechnicalException (s"Missing argument for S3 connection : ${IoCommon.accessKeyOption} " +
          s"in the passwords : ${IoCommon.displayMapOfStrings(passwords)}")
      }
      Map(
        IoCommon.endpointOption -> endpointOption,
        IoCommon.secretKeyOption -> secretKeyOption,
        IoCommon.accessKeyOption -> accessKeyOption
      )
    } else
      throw TechnicalException(s"Exception raised while Reading Json Config File on s3; " +
        s"${IoCommon.displayMapOfStrings(myMap = properties ++ passwords)} does not contain the mandatory options : " +
        s"${IoCommon.displayListOfStrings(myList = IoCommon.s3MandatoryOptions)}")
  }

  /**
   * This function will read the configuration with the password value replaced if a jceks file is defined
   *
   * @param arguments Map of String which contains the arguments of the program
   * @param prop      Map of String which contains the properties of the program
   * @param hdfs      HDFS FileSystem connection
   * @param conf_H    HDFS Connection
   * @param reporting Reporting to write log to the CR
   * @param spark     Implicit Spark Session
   * @return
   */
  def getFullConf(arguments: Map[String, String],
                  prop: MMap[String, String],
                  hdfs: FileSystem,
                  conf_H: Configuration,
                  reporting: Reporting)
                 (implicit spark: SparkSession): (String, Map[String, String]) = {
    addMandatoryPropertiesToReporting(prop = prop, reporting = reporting)
    val passwordsMap = getPasswords(prop = prop.toMap, conf_H = conf_H)
    IoCommon.displayMapOfStrings(myMap = passwordsMap)
    val s3Config = getS3Config(properties = prop.toMap, passwords = passwordsMap)
    IoCommon.displayMapOfStrings(myMap = s3Config)
    val jsonFile = getJsonConfigFile(arguments = arguments, prop = prop.toMap, passwords = passwordsMap, hdfs = hdfs)
    (getUpdatedConfigFile(jsonFile = jsonFile, passwords = passwordsMap), passwordsMap)
  }
}
