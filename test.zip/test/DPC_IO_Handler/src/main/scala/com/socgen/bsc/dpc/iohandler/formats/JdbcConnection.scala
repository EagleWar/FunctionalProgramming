package com.socgen.bsc.dpc.iohandler.formats

import com.socgen.bsc.dpc.common.exception.TechnicalException
import com.socgen.bsc.dpc.iohandler.common.IoCommon
import com.socgen.bsc.dpc.iohandler.input.InputConfiguration
import com.socgen.bsc.dpc.iohandler.output.OutputConfiguration
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * This object is used to read a DataFrame using a jdbc connection and to write a DataFrame using a jdbc connection
 */
object JdbcConnection {

  /**
   * Driver Class Path
   */
  private val trinoDriverClassPath = "io.trino.jdbc.TrinoDriver"
  private val postgresqlDriverClassPath = "org.postgresql.Driver"
  private val sqlDriverClassPath = "com.microsoft.sqlserver.jdbc.SQLServerDriver"
  private val prestoDriverClassPath = "io.prestosql.jdbc.PrestoDriver"

  /**
   * This function uses the url to identify the associated jdbc ClassPath
   *
   * @param url jdbc connection's url
   */
  private def getJdbcDriverClassPath(url: String): String = {
    val classPath = if (url.startsWith("jdbc:trino")) {
      trinoDriverClassPath
    } else if (url.startsWith("jdbc:postgresql")) {
      postgresqlDriverClassPath
    } else if (url.startsWith("jdbc:sqlserver")) {
      sqlDriverClassPath
    } else if (url.startsWith("jdbc:presto")) {
      prestoDriverClassPath
    } else {
      throw TechnicalException(s"Unrecognized jdbc source for url : '$url'")
    }
    if (classPath.nonEmpty && Class.forName(classPath) != null) {
      classPath
    } else {
      throw TechnicalException(s"Class $classPath not found in the CLASSPATH")
    }
  }

  //region read

  /**
   * This function will write a DataFrame using a jdbc connection according to the configuration defined in the
   * InputConfiguration object
   *
   * @param inputConfiguration InputConfiguration which specify the configuration to read the DataFrame from the defined
   *                           jdbc connection
   * @param spark              Implicit Spark Session
   */
  def readFromInputConfig(inputConfiguration: InputConfiguration)
                         (implicit spark: SparkSession): DataFrame = {
    read(options = inputConfiguration.options.getOrElse(Map.empty[String, String]))
  }

  /**
   * This function will read a DataFrame from a jdbc connection according to the configuration defined in the argument
   * and will get the driver ClassPath by recognizing the type of jdbc connection
   *
   * @param options Map of string which must contain the mandatory jdbc options
   * @param spark   Implicit Spark Session
   */
  def read(options: Map[String, String])
          (implicit spark: SparkSession): DataFrame = {
    try {
      if (IoCommon.hasMandatoryOptions(options = options, mandatoryOptions = IoCommon.jdbcMandatoryOptions)) {
        val driverClassPath = getJdbcDriverClassPath(options(IoCommon.urlOption))
        read(options = options, driverClassPath = driverClassPath)
      } else
        throw TechnicalException(s"A mandatory option is missing among the ${IoCommon.jdbcMandatoryOptions}. " +
          s"The options are ${IoCommon.displayMapOfStrings(myMap = options)}")
    } catch {
      case e: Exception => throw TechnicalException(s"An error occurred while reading input source with the " +
        s"following configuration ${IoCommon.urlOption} : ${options(IoCommon.urlOption)}; ERROR $e")
    }
  }

  /**
   * This function will read a DataFrame from a jdbc connection according to the configuration defined in the argument
   *
   * @param options         Map of string which must contain the mandatory jdbc options
   * @param driverClassPath Driver ClassPath to read
   * @param spark           Implicit Spark Session
   */
  private def read(options: Map[String, String], driverClassPath: String)(implicit spark: SparkSession): DataFrame = {
    try {
      val readOptions = options + (IoCommon.driverOption -> driverClassPath)
      spark.read
        .format("jdbc")
        .options(options = readOptions)
        .load()
    } catch {
      case e: Exception =>
        throw TechnicalException(s"An error occurred while executing the jdbc reading for $driverClassPath ; ERROR: $e")
    }
  }
  //endregion

  //region Write

  /**
   * This function will write a DataFrame using a jdbc connection according to the configuration defined in the
   * OutputConfiguration object
   *
   * @param df                  DataFrame to write
   * @param outputConfiguration OutputConfiguration which specify the configuration to save the DataFrame in the defined jdbc connection
   * @param mode                SaveMode - either append or overwrite
   * @param spark               Implicit Spark Session
   */
  def writeToOutputConfig(df: DataFrame,
                          outputConfiguration: OutputConfiguration,
                          mode: Option[String])
                         (implicit spark: SparkSession): Unit = {
    write(df = df,
      mode = mode.getOrElse(outputConfiguration.mode),
      coalesce = outputConfiguration.coalesce,
      options = outputConfiguration.options.getOrElse(Map.empty[String, String]))
  }

  /**
   * This function will write a DataFrame using a jdbc connection according to the configuration defined in the arguments
   * and will get the driver ClassPath by recognizing the type of jdbc connection
   *
   * @param df       DataFrame to write
   * @param mode     SaveMode - either append or overwrite
   * @param coalesce Coalesce degree to reduce the number of partitions and reduce the number of output files
   * @param options  Map of string which must contain the
   * @param spark    Implicit Spark Session
   */
  def write(df: DataFrame,
            mode: String,
            coalesce: Option[Int] = None,
            options: Map[String, String])
           (implicit spark: SparkSession): Unit = {
    try {
      if (df.count > 0) {
        if (IoCommon.hasValidMode(mode = mode))
          if (IoCommon.hasMandatoryOptions(options = options, mandatoryOptions = IoCommon.jdbcMandatoryOptions)) {
            val driverClassPath = getJdbcDriverClassPath(options(IoCommon.urlOption))
            write(df = df,
              mode = mode,
              coalesce = coalesce,
              driverClassPath = driverClassPath,
              options = options)
          } else {
            throw TechnicalException(s"A mandatory option is missing among the ${IoCommon.jdbcMandatoryOptions}. " +
              s"The options are ${IoCommon.displayMapOfStrings(myMap = options)}")
          }
        else {
          throw TechnicalException(s"Invalid Mode $mode, " +
            s"mode must be one of the following ${IoCommon.displayListOfStrings(myList = IoCommon.availableModes)}")
        }
      }
    } catch {
      case e: Exception =>
        throw TechnicalException(s"An error occurred while writing dataframe with the following configuration " +
          s"${IoCommon.urlOption} : ${options(IoCommon.urlOption)}; ERROR $e")
    }
  }

  /**
   * This function will write a DataFrame using a jdbc connection according to the configuration defined in the arguments
   *
   * @param df              DataFrame to write
   * @param mode            SaveMode - either append or overwrite
   * @param coalesce        Coalesce degree to reduce the number of partitions and reduce the number of output files
   * @param driverClassPath Driver ClassPath to write
   * @param options         Map of string which must contain the configuration
   * @param spark           Implicit Spark Session
   */
  private def write(df: DataFrame,
                    mode: String,
                    coalesce: Option[Int],
                    driverClassPath: String,
                    options: Map[String, String])
                   (implicit spark: SparkSession): Unit = {
    try {
      val writeOptions = options + (IoCommon.driverOption -> driverClassPath)
      df.coalesce(coalesce.getOrElse(1))
        .write.format("jdbc")
        .mode(mode)
        .options(options = writeOptions)
        .save()
    } catch {
      case e: Exception =>
        throw TechnicalException(s"An error occurred while executing the jdbc reading for $driverClassPath ; ERROR: $e")
    }
  }
  //endregion


  //region source

  /**
   * This function will return a string that will identify the source as clearly as possible. In this case for jdbc,
   * it will return the concatenation of the url and the database separated by a '|'
   *
   * @param options Map of string which must contain the jdbc configuration
   * @param spark   Implicit Spark Session
   */
  def getSource(options: Map[String, String])(implicit spark: SparkSession): String = {
    try {
      if (IoCommon.hasMandatoryOptions(options = options, mandatoryOptions = IoCommon.jdbcMandatoryOptions)) {
        s"${options(IoCommon.urlOption)}|${options(IoCommon.dbTableOption)}"
      } else
        throw TechnicalException(s"A mandatory option is missing among the ${IoCommon.jdbcMandatoryOptions}. " +
          s"The options are ${IoCommon.displayMapOfStrings(myMap = options)}")
    } catch {
      case e: Exception =>
        throw TechnicalException(s"An error occurred while reading input source with the following configuration " +
          s"${IoCommon.urlOption} : ${options(IoCommon.urlOption)}; ERROR $e")
    }
  }
  //endregion
}