package com.socgen.bsc.dpc.iohandler.formats

import com.socgen.bsc.dpc.common.exception.TechnicalException
import com.socgen.bsc.dpc.iohandler.input.InputConfiguration
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * This object is used to create a DataFrame from an sql query
 */
object HqlQuery {

  //region read

  /**
   * This function create a DataFrame from an sql query stored in an Input Configuration object
   *
   * @param inputConfiguration InputConfiguration which specify the configuration to generate a DataFrame from a query
   * @param spark              Implicit Spark Session
   */
  def readFromInputConfig(inputConfiguration: InputConfiguration)(implicit spark: SparkSession): DataFrame = {
    read(query = inputConfiguration.source)
  }

  /**
   * * This function create a DataFrame from the sql query arguments
   *
   * @param query sql query used to create the DataFrame
   * @param spark Implicit Spark Session
   */
  def read(query: String)(implicit spark: SparkSession): DataFrame = {
    try {
      spark.sql(query)
    } catch {
      case e: Exception => throw TechnicalException(s"An error occurred while executing SQL Query : $query ; ERROR: $e")
    }
  }
  //endregion
}