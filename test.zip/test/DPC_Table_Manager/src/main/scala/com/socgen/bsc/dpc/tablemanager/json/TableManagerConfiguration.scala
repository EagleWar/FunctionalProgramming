package com.socgen.bsc.dpc.tablemanager.json

import com.socgen.bsc.dpc.iohandler.input.InputConfiguration
import com.socgen.bsc.dpc.iohandler.output.OutputConfiguration

/** *
 * This case class define the configuration for Table Manager
 *
 * @param input   Input of type InputConfiguration that will be used as source
 * @param outputs Sequence of OutputConfiguration objects that we be used as destinations
 */
case class TableManagerConfiguration(
                                      input: InputConfiguration,
                                      outputs: Seq[OutputConfiguration]
                                    )