package com.socgen.bsc.dpc.tablemanager.json

import com.socgen.bsc.dpc.iohandler.dataframe.{Action, QueriesOptions}
import com.socgen.bsc.dpc.iohandler.input.InputConfiguration
import com.socgen.bsc.dpc.iohandler.output.OutputConfiguration
import spray.json._

/**
 * This object define the method to read a sequence of TableManagerConfiguration from a Json String
 */
object TableManagerConfigurationParser extends DefaultJsonProtocol {
  case class ArrayFormatterConfiguration(configs: Seq[TableManagerConfiguration])

  implicit object JsonConfigs extends RootJsonFormat[ArrayFormatterConfiguration] {
    /**
     * Json Decoder
     */
    implicit val actionFormat: RootJsonFormat[Action] = jsonFormat7(Action)
    implicit val queriesOptionsFormat: RootJsonFormat[QueriesOptions] = jsonFormat2(QueriesOptions)
    implicit val inputConfigsFormat: RootJsonFormat[InputConfiguration] = jsonFormat5(InputConfiguration)
    implicit val outputConfigsFormat: RootJsonFormat[OutputConfiguration] = jsonFormat9(OutputConfiguration)
    implicit val configsFormat: RootJsonFormat[TableManagerConfiguration] = jsonFormat2(TableManagerConfiguration)

    /**
     * This function will read an ArrayformatterConfiguration from a JsValue
     *
     * @param value JsValue of ArrayformatterConfiguration
     * @return
     */
    def read(value: JsValue): ArrayFormatterConfiguration =
      ArrayFormatterConfiguration(value.convertTo[List[TableManagerConfiguration]])

    /**
     * This function will write ArrayformatterConfiguration as a JsValue
     *
     * @param obj Object of type ArrayformatterConfiguration that will be encoded to a JsValue
     * @return
     */
    def write(obj: ArrayFormatterConfiguration): JsValue = obj.configs.toJson
  }

  /**
   * This function will parse a String to extract a Sequence of TableManagerConfiguration
   *
   * @param jsonConfigs A String which must be the Json representation of a sequence of TableManagerConfiguration
   * @return
   */
  def parseCleanConfigs(jsonConfigs: String): Seq[TableManagerConfiguration] =
    jsonConfigs.parseJson.convertTo[ArrayFormatterConfiguration].configs
}