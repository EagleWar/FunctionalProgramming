package com.socgen.bsc.collect;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class Main {

    static final int READING_CHUNK_SIZE = 10000;
    static final int WRITING_CHUNK_SIZE = 2000;

    public static List<String> loadQueries() {
        ArrayList<String> queries =new ArrayList<String>();

        //////////////////////////////////////////////////////////////////////////////////////////////////////////
        // MYAPRC                                                                                               //
        //////////////////////////////////////////////////////////////////////////////////////////////////////////

        queries.add("SELECT id,code,created_by, date_creation::timestamp(0), date_end_validity::timestamp(0), date_integration::timestamp(0), date_start_validity::timestamp(0),id_parent,is_activated,label_en,label_fr,level,ordre,id_global,id_global_parent,nom_court_en,nom_court_fr FROM activity");
        queries.add("SELECT id_activity, id_macroprocess FROM activity_macroprocess");
        queries.add("SELECT id, commentary, created_by,  date_creation::timestamp(0), etat, id_activity, id_macroprocess, id_matrix_version, id_process FROM amppr");
        queries.add("SELECT id, anomalie_collect_en, anomalie_collect_fr, conseils_en, conseils_fr, cotation_ctrl_en, cotation_ctrl_fr, created_by,  date_creation::timestamp(0), desc_metho_echantlg_en, desc_metho_echantlg_fr, doc_normative_grp_en, doc_normative_grp_fr, doc_realisation_grp_en, doc_realisation_grp_fr, elmt_besoin_ctrl_en, elmt_besoin_ctrl_fr, id_ref, ind_cle_en, ind_cle_fr, is_activated, nom_besoin_ctrl_en, nom_besoin_ctrl_fr, obj_besoin_ctrl_en, obj_besoin_ctrl_fr, ref_bcn, ref_bcn_modifiee, version_bcn, periodicite, lo_d2_proprietaire, is_hpc, alias,  date_update::timestamp(0), updated_by, theme FROM control");
        queries.add("SELECT id_control, id_domain FROM control_domain");
        queries.add("SELECT id, code_iso_2a, code_iso_3a, created_by,  date_creation::timestamp(0),  date_end_validity::timestamp(0),  date_integration::timestamp(0),  date_start_validity::timestamp(0), id_ref, is_activated, label_en, label_fr FROM country");
        queries.add("SELECT id, code, label_en, label_fr, ordre FROM domain");
        queries.add("SELECT id, created_by,  created_date::timestamp(0), id_person, id_country, id_legal_entity, id_macroprocess, id_operational_entity, id_risk, id_role FROM empowerment_perimeter");
        queries.add("SELECT id, code, label_en, label_fr, ordre FROM frequency");
        queries.add("SELECT id, code_magnitude, code_stp, created_by,  date_creation::timestamp(0),  date_end_validity::timestamp(0),  date_start_validity::timestamp(0), id_ref, identifiant_ej_local, is_activated, label_en, label_fr, version, id_country FROM legal_entity");
        queries.add("SELECT id_legal_entity, id_operational_entity FROM legal_operational_entity");
        queries.add("SELECT id, code, label_en, label_fr, ordre FROM lod2owner");
        queries.add("SELECT id, code, created_by,  date_creation::timestamp(0),  date_end_validity::timestamp(0),  date_integration::timestamp(0),  date_start_validity::timestamp(0), is_activated, label_en, label_fr, id_global, id_global_parent, nom_court_en, nom_court_fr FROM macroprocess");
        queries.add("SELECT id, created_by,  created_date::timestamp(0), current_version, is_locked,  lock_date::timestamp(0), locked_by, label FROM matrix");
        queries.add("SELECT id, created_by,  created_date::timestamp(0), label, version, id_country, id_legal_entity, id_matrix, id_operational_entity, id_status, merged_from FROM matrix_version");
        queries.add("SELECT id, commentary, created_by,  date_creation::timestamp(0), etat, id_amppr, id_control FROM obj_control_matrix");
        queries.add("SELECT id, created_by,  date_creation::timestamp(0),  date_end_validity::timestamp(0),  date_start_validity::timestamp(0), elr_rattachement, id_parent, id_ref, is_activated, label_court_en, label_court_fr, label_long_en, label_long_fr, level, mnemonique, path FROM operational_entity");
        queries.add("SELECT id, created_by,  created_date::timestamp(0), first_name, last_name, updated_by,  updated_date::timestamp(0) FROM person");
        queries.add("SELECT id, created_by,  date_creation::timestamp(0), is_activated, id_control, id_process, id_risk,  first_creation_date::timestamp(0) FROM prc_ref");
        queries.add("SELECT id, code, created_by,  date_creation::timestamp(0),  date_end_validity::timestamp(0),  date_integration::timestamp(0),  date_start_validity::timestamp(0), description_en, description_fr, id_macroprocess, is_activated, label_en, label_fr, ordre, id_global, id_global_parent, nom_court_en, nom_court_fr FROM process");
        queries.add("SELECT id, created_by,  date_creation::timestamp(0),  date_end_validity::timestamp(0),  date_start_validity::timestamp(0), id_ref, id_parent, is_activated, label_en, label_fr FROM risk");
        queries.add("SELECT id, code, label_en, label_fr FROM role");
        queries.add("SELECT id, label_en, label_fr FROM status");
        queries.add("SELECT id, created_by,  date_creation::timestamp(0), id_control_level_one, id_obj_control_matrix FROM control_level_one_process");
        queries.add("SELECT id, alias, control_json, created_by,  date_creation::timestamp(0), date_update, elr_execution_json, eo_coverage_json, eo_execution_json, id_ref, is_activated, label_en, label_fr, process_json, risk_json, updated_by, id_mitigant_type, id_source, date_reactivation FROM control_level_one");
        queries.add("SELECT id, created_by,  date_creation::timestamp(0), id_matrix_version, is_by_myself, id_control_level_one, id_matrix FROM control_level_one_matrix_mapping");
        queries.add("SELECT id, code, label_en, label_fr FROM params_reference");
        queries.add("SELECT id, created_by,  date_creation::timestamp(0), is_activated, id_control, id_regulation FROM control_regulation");
        queries.add("SELECT id, code, label_en, label_fr, ordre FROM regulation");
        queries.add("SELECT id, created_by,  date_creation::timestamp(0), is_activated, id_control, id_control_expert FROM control_expert_control");
        queries.add("SELECT id, code, label_en, label_fr, ordre FROM control_expert");
        queries.add("SELECT id, created_by,  date_creation::timestamp(0), is_activated, id_control, id_group_generic_control FROM control_group_generic_control");
        queries.add("SELECT id, id_ref FROM group_generic_control");
        queries.add("SELECT id, created_by,  date_creation::timestamp(0), is_activated, id_control, id_keyword FROM control_keyword");
        queries.add("SELECT id, code, label_en, label_fr, ordre FROM keyword");
        queries.add("SELECT id, code, label_en, label_fr, ordre FROM theme");

        return queries;
    }

    public static void main (String[] args) throws SQLException, FileNotFoundException {
        String url = args[0];
        Integer port = Integer.valueOf(args[1]);
        String database = args[2];
        String user = args[3];
        String passwd = args[4];
        String ouputPath =args[5];

        List<String> queries = loadQueries();
        Fetcher fetcher = new Fetcher(url, port, database);
        Connection connection = fetcher.connect(user, passwd);
        OutputStream outputStream = new FileOutputStream(new File(ouputPath));

        try {
            for (int i=0; i<queries.size();i++){
                fetcher.reset();
                System.out.println( queries.get(i));
                fetcher.fetchTable(connection, queries.get(i), i+1, WRITING_CHUNK_SIZE, READING_CHUNK_SIZE);
                String chunk = null;
                while ((chunk = fetcher.getNextChunk()) != null) {
                    outputStream.write(chunk.getBytes());
                    outputStream.flush();
                }
            }
            System.out.println(ouputPath);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            if (connection != null)
                connection.close();
        }
    }
}
