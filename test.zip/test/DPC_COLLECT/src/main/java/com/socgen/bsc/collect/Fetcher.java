package com.socgen.bsc.collect;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Fetcher {


    private String uri;

    private static String QURE_SEP = "|~|";
    private static String EOL_REPL = " ";
    private static String NULL_REPL = "";

    private int blockId;
    List<String> columnNames = new ArrayList<>();
    private ResultSetMetaData resultSetMetaData = null;
    private ResultSet resultSet = null;
    private int writingChunkSize;
    private int readingChunkSize;
    private List<String> queries = null;
    private boolean multiCSV = false;
    private Connection connection = null;
    private int currentQuery = 0;

    public Fetcher(String server, int port, String instance) {
        uri = String.format("jdbc:postgresql://%s:%s/%s", server, port, instance);
    }

    public Fetcher() {
        uri = "";
    }

    public Connection connect(String user, String password) throws SQLException {
        Connection connection = DriverManager.getConnection(uri, user, password);
        connection.setAutoCommit(false);
        return connection;
    }


    public void reset() {
        resultSet = null;
        resultSetMetaData = null;
        columnNames = new ArrayList<>();
    }

    private String doGetChunk() throws SQLException {
        String newLine = System.getProperty("line.separator");
        List<String> result = new ArrayList<>();

        for (int i = 1; i <= writingChunkSize; i++) {
            if (resultSet.next()) {
                StringBuilder line = new StringBuilder().append(Integer.toString(this.blockId));
                for (String c : this.columnNames) {
                    line.append(QURE_SEP);
                    String str = resultSet.getString(c);
                    if (str != null) line.append(str.replaceAll("[\\r\\n]", EOL_REPL));
                }
                line.append(newLine);

                result.add(
                        line.toString()
                                .replaceAll("(?<=^|[|~|])null(?=[|~|]|$)", NULL_REPL)
                                .replaceAll("(?<=^|[|~|])<None>(?=[|~|]|$)", NULL_REPL)
                                .replaceAll("(?<=[|~|]|^)(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2})(?=[|~|]|$)", "$1")
                );
            }
        }
        //resultSet.close();

        return result.size() > 0 ? String.join("", result) : null;
    }

    public String getNextChunk() throws SQLException {
        if (multiCSV) {
            if (resultSet == null || !resultSet.next()) {
                fetchTable(connection, queries.get(currentQuery), currentQuery + 1, writingChunkSize, readingChunkSize);
                currentQuery = currentQuery + 1;

                if (currentQuery > queries.size() - 1) {
                    return null;
                }
            }
        }

        return doGetChunk();
    }

    public void fetchTable(Connection connection, String query, int blockId, int writingChunkSize, int readingChunkSize) throws SQLException {
        this.blockId = blockId;
        this.writingChunkSize = writingChunkSize;
        this.readingChunkSize = readingChunkSize;
        connection.setAutoCommit(false);
        Statement stmt = connection.createStatement();
        stmt.setFetchSize(readingChunkSize);
        this.resultSet = stmt.executeQuery(query);
        this.resultSetMetaData = resultSet.getMetaData();

        for (int i = 1; i <= this.resultSetMetaData.getColumnCount(); i++) {
            this.columnNames.add(resultSetMetaData.getColumnName(i));
        }
    }

    public void fetchTablesAsMultiCSV(Connection connection, List<String> queries, int writingChunkSize, int readingChunkSize) {
        this.queries = queries;
        this.writingChunkSize = writingChunkSize;
        this.readingChunkSize = readingChunkSize;
        this.multiCSV = true;
        this.connection = connection;
    }
}