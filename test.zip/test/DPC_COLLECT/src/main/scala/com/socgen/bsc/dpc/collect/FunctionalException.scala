package main.scala.com.socgen.bsc.dpc.collect

case class FunctionalException(private val message: String = "",
                               private val cause: Throwable = None.orNull)
  extends Exception(message, cause)
