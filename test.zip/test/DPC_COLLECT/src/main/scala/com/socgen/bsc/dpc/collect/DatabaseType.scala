package main.scala.com.socgen.bsc.dpc.collect

object DatabaseType extends Enumeration {
  val Oracle, Postgre = Value
}
