package main.scala.com.socgen.bsc.dpc.collect

import java.io.{FileInputStream, InputStream}
import java.util.Properties

import scala.collection.JavaConverters._

import scala.collection.mutable

object Main {
  private val configPathArg = "configPath"
  private val outputPathArg = "outputPath"
  private val userArg = "user"
  private val passwordArg = "password"
  private val databaseTypeArg = "database"
  private val mandatoryArguments = Seq(configPathArg, outputPathArg, passwordArg, databaseTypeArg)

  // The databaseTypeArg should be one of the following
  private val ORACLE_DATABASE = "oracle"
  private val POSTGRE_DATABASE = "postgre"

  // Properties
  private val inputTablesProp = "inputTables"
  private val dbServerProp = "db_server"
  private val dbPortProp = "db_port"
  private val dbInstanceProp = "db_instance"
  private val firstStartDateProp = "first_start_date"
  private val mandatoryProperties = Seq(inputTablesProp, dbServerProp, dbPortProp, dbInstanceProp, firstStartDateProp)

  def parseArguments(map: Map[String, String], list: List[String]): Map[String, String] = {
    list match {
      case Nil => map
      case ("--config-path"|"-cp") :: path :: tail =>
        parseArguments(map ++ Map(configPathArg -> path), tail)
      case ("--output-path"|"-op") :: outputPath :: tail =>
        parseArguments(map ++ Map(outputPathArg -> outputPath), tail)
      case ("--user"|"-u") :: user :: tail =>
        parseArguments(map ++ Map(userArg -> user), tail)
      case ("--password"|"-p") :: password :: tail =>
        parseArguments(map ++ Map(passwordArg -> password), tail)
      case ("--db-type"|"-db") :: databaseType :: tail =>
        parseArguments(map ++ Map(databaseTypeArg -> databaseType), tail)
      case unknown :: tail =>
        parseArguments(map, tail)
    }
  }

  def checkMandatoryArguments(mandatoryArguments: Seq[String], arguments: Map[String, String]): Unit =
    if (!mandatoryArguments.forall(arguments.keySet.contains))
      throw FunctionalException(s"missing one of the required arguments ${mandatoryArguments.mkString(", ")}")

  def getProperties(inputStream: InputStream): mutable.Map[String, String] = {
    val prop = new Properties
    prop.load(inputStream)
    prop.asScala
  }

  def checkMandatoryProperties(mandatoryProperties: Seq[String], properties: mutable.Map[String, String]): Unit =
    if (!mandatoryProperties.forall(properties.keySet.contains))
      throw FunctionalException(s"missing one of the required properties ${mandatoryProperties.mkString(", ")}")

  def main(args: Array[String]): Unit = {
    val arguments = parseArguments(Map(),args.toList)

    checkMandatoryArguments(mandatoryArguments, arguments)

    val databaseType = arguments(databaseTypeArg) match {
      case ORACLE_DATABASE => DatabaseType.Oracle
      case POSTGRE_DATABASE => DatabaseType.Postgre
      case _ => throw FunctionalException(s"Impossible to parse ${arguments(databaseTypeArg)}. Should be $ORACLE_DATABASE or $POSTGRE_DATABASE")
    }

    val inputStream = new FileInputStream(arguments(configPathArg))
    inputStream match {
      case null => println(s"No such config path file ${arguments(configPathArg)}") // scalastyle:ignore
      case is: InputStream =>
        val prop = getProperties(is)
        checkMandatoryProperties(mandatoryProperties, prop)

        ExtractDataHandler.extractAndWriteTables(arguments(outputPathArg),
            prop(inputTablesProp), arguments(userArg), arguments(passwordArg), prop(dbServerProp),
            prop(dbPortProp), prop(dbInstanceProp), prop.get(firstStartDateProp), databaseType
        )
    }
  }
}
