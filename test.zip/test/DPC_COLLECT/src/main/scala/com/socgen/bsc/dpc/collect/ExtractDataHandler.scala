package main.scala.com.socgen.bsc.dpc.collect

import java.io.File
import java.io.FileWriter
import java.sql.DriverManager
import scala.collection.mutable.ListBuffer

object ExtractDataHandler {
  private val QURE_SEP = "|~|"
  private val EOL_REPL = " "
  private val NULL_REPL = ""
  private val FILTER_COLUMN = "START_DATE"
  private val FETCH_SIZE: Int = 20000

  def extractAndWriteTable(fw: FileWriter, blocId: Int, tableName: String, user: String, password: String, dbServer: String,
                           dbPort: String, dbInstance: String, firstStartDate: Option[String], databaseType: DatabaseType.Value): Unit = {

    val url = databaseType match {
      case DatabaseType.Oracle => s"jdbc:oracle:thin:@$dbServer:$dbPort/$dbInstance"
      case DatabaseType.Postgre => s"jdbc:postgresql://$dbServer:$dbPort/$dbInstance"
    }

    Class.forName("org.postgresql.Driver")

    val conn = DriverManager.getConnection(url, user, password)
    conn.setAutoCommit(false)

    var columnNames = new ListBuffer[String]()
    val metadata = conn.getMetaData()
    val resultSet = metadata.getColumns(null, null, tableName.split('.').last, null)
    while (resultSet.next())
      columnNames += resultSet.getString("COLUMN_NAME")

    // see this HowTo
    val sql =
      if (firstStartDate.isDefined && columnNames.contains(FILTER_COLUMN))
        s"SELECT * FROM $tableName where $FILTER_COLUMN >= TO_DATE('${firstStartDate.get}', 'yyyy-MM-dd')"
      else
        s"SELECT * FROM $tableName"

    val stmt = conn.createStatement
    stmt.setFetchSize(FETCH_SIZE)
    val rs = stmt.executeQuery(sql)

    while (rs.next()) {
      var line: String = blocId.toString
      for (c <- columnNames) {
        line += QURE_SEP
        val str = rs.getString(c)
        if (str != null) line += str.replaceAll("[\\r\\n]", EOL_REPL)
      }
      fw.write(
        line
          .replaceAll("(?<=^|[|~|])null(?=[|~|]|$)", NULL_REPL)
          .replaceAll("(?<=^|[|~|])<None>(?=[|~|]|$)", NULL_REPL)
          .replaceAll("(?<=[|~|]|^)(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2})(?=[|~|]|$)", "$1.0")
          + "\n"
      )
    }
    stmt.close
    rs.close
    fw.flush()
  }

  def extractAndWriteTables(outputPath: String, inputTableNamesWithFilters: String, user: String, password: String, dbServer: String,
                            dbPort: String, dbInstance: String, firstStartDate: Option[String], databaseType: DatabaseType.Value): Unit = {
    val fileTemp = new File(outputPath)
    if (fileTemp.exists)
      fileTemp.delete()

    val fw = new FileWriter(outputPath, true)

    inputTableNamesWithFilters.split(',').zipWithIndex.collect {
      case (table, blocId) => extractAndWriteTable(fw, blocId + 1, table.split('|')(0), user, password, dbServer,
        dbPort, dbInstance, if (table.split('|').size > 1) firstStartDate else None, databaseType) // blocId should start at one
    }
    fw.close()
  }
}
