package com.socgen.bsc.dpc.jobmon.consumers

import com.socgen.bsc.dpc.jobmon.JobMon
import com.socgen.bsc.dpc.jobmon.entries.{Jsonify, QueryEntry}
import io.circe._
import io.circe.parser._
import io.circe.syntax._
import org.apache.spark.sql.execution.ui.SparkListenerSQLExecutionEnd


//region Trait

trait QueryConsumer
{
    val name: String

    def triggerOn(queryEntry: QueryEntry, sqlEnd: SparkListenerSQLExecutionEnd): Unit
}

//endregion

//region Consumer definition

class QueryEntryFiller extends QueryConsumer
{
    val name = "QueryEntryFiller"

    def triggerOn(queryEntry: QueryEntry, sqlEnd: SparkListenerSQLExecutionEnd): Unit =
    {
        // Filling query entry
        queryEntry.queryEndTime = sqlEnd.time

        val relatedJobs = JobMon.getJobEntriesFromQuery(queryEntry)
        queryEntry.queryRecordsRead = relatedJobs.map(_.jobRecordsRead).sum
        queryEntry.queryRecordsWritten = relatedJobs.map(_.jobRecordsWritten).sum
        queryEntry.queryBytesRead = relatedJobs.map(_.jobBytesRead).sum
        queryEntry.queryBytesWritten = relatedJobs.map(_.jobBytesWritten).sum
        queryEntry.queryExecutorRunTime = relatedJobs.map(_.jobExecutorRunTime).sum
        queryEntry.queryExecutorCpuTime = relatedJobs.map(_.jobExecutorCpuTime).sum
        queryEntry.queryPeakMemory = relatedJobs.map(_.jobPeakMemory).max
        queryEntry.queryAverageMemory = JobMon.average(relatedJobs.map(_.jobAverageMemory))

        // Sending back to main object
        JobMon.addOrUpdateQueryEntry(queryEntry)
    }
}


class SavedTableFiller extends QueryConsumer
{
    override val name = "SaveQueryPrinter"

    val desc_trigger_words: Seq[String] = Seq("save", "parquet", "csv")

    private def findFirstByKey(json: Json, key: String, filterFunc: Json => Boolean): Option[Json] =
        json.findAllByKey(key).filter(filterFunc(_)) match
        {
            case first +: _ if first.isNull => Some(Json.Null)
            case first +: _                 => Some(first)
            case Nil                        => None
        }

    private def autoString(option: Option[Json]): String = option match
    {
        case Some(Json.Null) => "<Unknown>"
        case Some(json)      => json.toString
        case None            => "<NotFound>"
    }

    override def triggerOn(queryEntry: QueryEntry, sqlEnd: SparkListenerSQLExecutionEnd): Unit =
    {
        // Searching for specific words in query description, and skipping all others.
        if (!desc_trigger_words.exists(queryEntry.queryDescription.contains(_))) return

        // Query information
        val id = queryEntry.queryId
        val name = queryEntry.sparkPlanInfo.nodeName

        // Plan information
        val planJson = parse(queryEntry.queryExecution.executedPlan.toJSON) match
        {
            case Left(_)     => Json.Null
            case Right(json) => json
        }

        // [0]/cmd/[0]/table/identifier/_ (table, database)
        val tableName = autoString(findFirstByKey(planJson, "table", _.isString))
        val database = autoString(findFirstByKey(planJson, "database", _.isString))
        // [0]/cmd/[0]/table/_ (tableType/name)
        val tableType = autoString(findFirstByKey(planJson, "tableType", _.isObject)
                                   .flatMap(findFirstByKey(_, "name", _.isString)))
        // [0]/cmd/[0]/table/storage/_ (locationUri, compressed)
        val locationUri = autoString(findFirstByKey(planJson, "locationUri", _.isString))
        val compressed = autoString(findFirstByKey(planJson, "compressed", _.isBoolean))
        // [0]/cmd/[0]/table/_ (provider)
        val provider = autoString(findFirstByKey(planJson, "provider", _.isString))
        // [0]/cmd/[0]/_ (mode, outputColumnNames)
        val mode = autoString(findFirstByKey(planJson, "mode", _.isString))
        val outputColumnNames = autoString(findFirstByKey(planJson, "outputColumnNames", _.isString))
        // [0]/cmd/[1]/_ (numPartitions)
        val numPartitions = autoString(findFirstByKey(planJson, "numPartitions", _.isNumber))

        queryEntry.querySavedTable = Some(QueryEntry.SavedTable(tableName,
                                                                database,
                                                                tableType,
                                                                locationUri,
                                                                compressed,
                                                                provider,
                                                                mode,
                                                                outputColumnNames,
                                                                numPartitions))

        JobMon.addOrUpdateQueryEntry(queryEntry)
    }
}


class TinyQueryPrinter extends QueryConsumer
{
    override val name = "TinyQueryPrinter"

    override def triggerOn(queryEntry: QueryEntry, sqlEnd: SparkListenerSQLExecutionEnd): Unit =
    {
        // Query info
        val id = queryEntry.queryId
        val name = queryEntry.sparkPlanInfo.nodeName

        println(
            s"[JOBMON][QUERY] Query $name (#$id) finished :\n"
                + s" ~ Description : ${queryEntry.queryDescription}.\n"
                + s" ~ Related jobs (${queryEntry.queryRelatedJobIds.size}): ${
                queryEntry.queryRelatedJobIds.mkString(", ")
            }.\n"
                //+ s" ~ Metrics accumulators : ${queryEntry.queryExecution.executedPlan.metrics.mkString(", ")}.\n"
                + s" ~ Records read/written : ${queryEntry.queryRecordsRead} / ${queryEntry.queryRecordsWritten}.\n"
                + s" ~ Absolute time taken : ${queryEntry.queryEndTime - queryEntry.queryStartTime} ms.\n"
                + s" ~ Executor run time : ${queryEntry.queryExecutorRunTime} ms; Executor cpu time : ${queryEntry.queryExecutorCpuTime} ms."

            //+ s" ~ Physical Plan :\n ~ -> "
            //+ queryEntry.physicalPlanDescription.replaceAll("\n", "\n ~ -> ")
            )
    }
}


class SavedTablePrinter extends QueryConsumer
{
    override val name = "SavedTablePrinter"

    val desc_trigger_words: Seq[String] = Seq("save", "parquet", "csv")

    override def triggerOn(queryEntry: QueryEntry, sqlEnd: SparkListenerSQLExecutionEnd): Unit =
    {
        // Searching for specific words in query description, and skipping all others.
        if (!desc_trigger_words.exists(queryEntry.queryDescription.contains(_))) return

        // Query info
        val id = queryEntry.queryId
        val table = queryEntry.querySavedTable.get

        // Actual printing
        println(
            s"[JOBMON][QUERY] Writing query ${queryEntry.queryDescription} (#$id) detected !\n"
                + s" ~ Table name : ${table.tableName}; Located in database : ${table.database}.\n"
                + s" ~ It wrote ${queryEntry.queryRecordsWritten} lines on ${table.numPartitions} partitions.\n"
                + s" ~ Writing mode : ${table.mode}; Table type : ${table.tableType} (${table.provider}).\n"
                + s" ~ Writing location : ${table.locationUri} (compressed: ${table.compressed}).\n"
                + s" ~ Output columns : ${table.outputColumnNames}.")
    }
}


class JsonQueryPrinter extends QueryConsumer
{
    override val name = "JsonQueryPrinter"

    override def triggerOn(queryEntry: QueryEntry, sqlEnd: SparkListenerSQLExecutionEnd): Unit =
    {
        import Jsonify.queryEntryEncoder
        println(s"[JOBMON][QUERY] Writing query json :\n${queryEntry.asJson}")
    }
}


class QuerySummaryPublisher extends QueryConsumer
{
    val name = "QuerySummaryPublisher"

    override def triggerOn(queryEntry: QueryEntry, sqlEnd: SparkListenerSQLExecutionEnd): Unit =
        JobMon.sendJsonToEs(queryEntry, "queries")
}

// TODO : Add more consumers as needed

//endregion