package com.socgen.bsc.dpc.jobmon.entries

import io.circe._
import io.circe.generic.semiauto._
import io.circe.syntax._

object Jsonify
{
    def prefixId[T](id: T): String = s"${EsWrapper.appId}:$id"

    // App entry
    implicit val appEntryEncoder: Encoder[AppEntry] = deriveEncoder

    // Job entry
    implicit val jobEntryEncoder: Encoder[JobEntry] =
        Encoder.forProduct15(
            "jobId", "relatedQueryId", "jobStartTime", "jobEndTime", "jobResult",
            "jobRecordsRead", "jobRecordsWritten", "jobBytesRead", "jobBytesWritten",
            "jobExecutorRunTime", "jobExecutorCpuTime", "jobPeakMemory", "jobAverageMemory",
            "failedStage", "failedStageReasons"
            )(je => (
            prefixId(je.jobId), je.relatedQueryId, je.jobStartTime, je.jobEndTime, je.jobResult.getOrElse(
            "<Unknown>").toString,
            je.jobRecordsRead, je.jobRecordsWritten, je.jobBytesRead, je.jobBytesWritten,
            je.jobExecutorRunTime, je.jobExecutorCpuTime, je.jobPeakMemory, je.jobAverageMemory,
            je.jobFailedStage, je.failedStageReasons.values))

    // Query entry

    // Inner class is trivial
    implicit val saveTableEncoder: Encoder[QueryEntry.SavedTable] = deriveEncoder
    // Outer class is not
    implicit val queryEntryEncoder: Encoder[QueryEntry] =
    {
        Encoder.forProduct21(
            // Query related info
            "queryId", "queryStartTime",
            //  Info gotten from SQL START spark listener
            "planNodeName", "queryDetails", "queryDescription", "physicalPlanDescription",
            // Related job infos
            "queryRelatedJobIds",
            "queryRecordsRead", "queryRecordsWritten", "queryBytesRead", "queryBytesWritten",
            "queryExecutorRunTime", "queryExecutorCpuTime", "queryPeakMemory", "queryAverageMemory",
            // Metrics gotten from DriverAccumUpdatesM
            "queryMetrics",
            // Used only for queries that saves tables
            "queryIsSavedTable", "querySavedTable",
            // Info gotten from SQL END spark listener
            "queryEndTime", "querySuccess", "queryFailReason"
            )(qe => (
            // Query related info
            prefixId(qe.queryId), qe.queryStartTime,
            //  Info gotten from SQL START spark listener
            qe.sparkPlanInfo.nodeName, qe.queryDetails, qe.queryDescription, qe.physicalPlanDescription,
            // Related job infos
            qe.queryRelatedJobIds,
            qe.queryRecordsRead, qe.queryRecordsWritten, qe.queryBytesRead, qe.queryBytesWritten,
            qe.queryExecutorRunTime, qe.queryExecutorCpuTime, qe.queryPeakMemory, qe.queryAverageMemory,
            // Metrics gotten from DriverAccumUpdatesM
            qe.queryMetrics,
            // Used only for queries that saves tables
            qe.querySavedTable.isDefined, qe.querySavedTable.map(_.asJson).getOrElse(Json.Null),
            // Info gotten from SQL END spark listener
            qe.queryEndTime, qe.querySuccess.map(_.asJson).getOrElse(Json.Null),
            qe.queryFailReason.map(_.asJson).getOrElse(Json.Null)))
    }

    // Executor entry

    implicit val executorEntryEncoder: Encoder[ExecutorEntry] =
        Encoder.forProduct7(
            // Basic info
            "executorId", "executorHost", "totalCores",
            // Lifespan
            "executorStartTime", "executorEndTime",
            "removedReason",
            // Automatically changed by ConsumerManager before calling map
            "executorStatus")(ee => (
            // Basic info
            prefixId(ee.executorId), ee.executorHost, ee.totalCores,
            // Lifespan
            ee.executorStartTime, if (ee.executorEndTime != -1) ee.executorEndTime.asJson else Json.Null,
            ee.removedReason.getOrElse("<Unknown>"),
            // Automatically changed by ConsumerManager before calling map
            ee.executorStatus.id))

    // Es Wrappers
    implicit val appEsWrapperEncoder: Encoder[AppEsWrapper] = deriveEncoder
    implicit val queryEsWrapperEncoder: Encoder[QueryEsWrapper] = deriveEncoder
    implicit val jobEsWrapperEncoder: Encoder[JobEsWrapper] = deriveEncoder
    implicit val executorEsWrapperEncoder: Encoder[ExecutorEsWrapper] = deriveEncoder
}

