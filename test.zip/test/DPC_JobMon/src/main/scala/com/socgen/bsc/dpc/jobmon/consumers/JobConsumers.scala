package com.socgen.bsc.dpc.jobmon.consumers

import com.socgen.bsc.dpc.jobmon.JobMon
import com.socgen.bsc.dpc.jobmon.entries.{JobEntry, Jsonify}
import io.circe.syntax._
import org.apache.spark.scheduler.SparkListenerJobEnd


//region Trait

trait JobConsumer
{
    val name: String

    def triggerOn(jobEntry: JobEntry, jobEnd: SparkListenerJobEnd): Unit
}

//endregion

//region Consumer definition

class JobEntryFiller extends JobConsumer
{
    val name = "JobEntryFiller"

    override def triggerOn(jobEntry: JobEntry, jobEnd: SparkListenerJobEnd): Unit =
    {
        // Filling said job entry
        jobEntry.jobEndTime = jobEnd.time
        jobEntry.jobResult = Some(jobEnd.jobResult)

        jobEntry.jobRecordsRead = jobEntry.recordsRead.values.sum
        jobEntry.jobRecordsWritten = jobEntry.recordsWritten.values.sum

        jobEntry.jobBytesRead = jobEntry.bytesRead.values.sum
        jobEntry.jobBytesWritten = jobEntry.bytesWritten.values.sum

        jobEntry.jobExecutorRunTime = jobEntry.executorRunTime.values.sum
        jobEntry.jobExecutorCpuTime = jobEntry.executorCpuTime.values.sum

        jobEntry.jobPeakMemory = jobEntry.peakMemory.values.max
        jobEntry.jobAverageMemory = JobMon.average(jobEntry.peakMemory.values)

        // Sending back to main object
        JobMon.addOrUpdateJobEntry(jobEntry)
    }
}


class JsonJobPrinter extends JobConsumer
{
    val name = "JsonJobPrinter"

    override def triggerOn(jobEntry: JobEntry, jobEnd: SparkListenerJobEnd): Unit =
    {
        import Jsonify.jobEntryEncoder
        println(s"[JOBMON][JOB] Writing job json :\n${jobEntry.asJson}")
    }
}


class JobSummaryPublisher extends JobConsumer
{
    val name = "JobSummaryPublisher"

    override def triggerOn(jobEntry: JobEntry, jobEnd: SparkListenerJobEnd): Unit =
        JobMon.sendJsonToEs(jobEntry, "jobs")
}

// TODO : Add more consumers as needed

//endregion