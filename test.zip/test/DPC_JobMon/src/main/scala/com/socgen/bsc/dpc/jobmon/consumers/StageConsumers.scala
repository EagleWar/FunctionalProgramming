package com.socgen.bsc.dpc.jobmon.consumers

import com.socgen.bsc.dpc.jobmon.JobMon
import com.socgen.bsc.dpc.jobmon.entries.JobEntry
import org.apache.spark.scheduler.SparkListenerStageCompleted

//region Trait

trait StageConsumer
{
    val name: String

    def triggerOn(jobEntry: JobEntry, stageCompleted: SparkListenerStageCompleted): Unit
}

//endregion

//region Consumer definition

class FailureRecorder extends StageConsumer
{
    val name = "FailureRecorder"

    override def triggerOn(jobEntry: JobEntry, stageCompleted: SparkListenerStageCompleted): Unit =
    {
        // Skipping successful stages
        if (stageCompleted.stageInfo.failureReason.isEmpty)
            return

        // Saving information on linked job entry
        jobEntry.failedStageReasons += (stageCompleted.stageInfo.stageId -> stageCompleted.stageInfo.failureReason.get)

        // Sending back to main object
        JobMon.addOrUpdateJobEntry(jobEntry)
    }
}

// TODO : Add more consumers as needed

//endregion