#!/bin/bash

clear_indexes () {
    printf "ACTION : DELETE ; INDEX : $1-apps\n"
    curl -XDELETE https://dhadlx140.dns21.socgen:9200/$1-apps -k -u "es_bsc_dpc:IdGEXbbJaWlrCcjNLg==";
    printf "\nACTION : DELETE ; INDEX : $1-queries\n"
    curl -XDELETE https://dhadlx140.dns21.socgen:9200/$1-queries -k -u "es_bsc_dpc:IdGEXbbJaWlrCcjNLg==";
    printf "\nACTION : DELETE ; INDEX : $1-jobs\n"
    curl -XDELETE https://dhadlx140.dns21.socgen:9200/$1-jobs -k -u "es_bsc_dpc:IdGEXbbJaWlrCcjNLg==";
    printf "\nACTION : DELETE ; INDEX : $1-executors\n"
    curl -XDELETE https://dhadlx140.dns21.socgen:9200/$1-executors -k -u "es_bsc_dpc:IdGEXbbJaWlrCcjNLg==";
}

clear_indexes $1

#./clear_indexes.sh bscdpchprd-jobmontest