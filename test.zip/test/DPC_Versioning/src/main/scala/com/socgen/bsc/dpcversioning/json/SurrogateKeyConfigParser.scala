package com.socgen.bsc.dpcversioning.json

import spray.json._

// defining case classes for json structure
case class Field(newField: String, fieldsToConcat: String, sep: String)

case class Table(table: String, fields: Seq[Field])

// JSON parser for surrogate key config
object SurrogateKeyConfigParser extends DefaultJsonProtocol {

  // Case class for all elements of surrogate key config
  case class TablesArray(items: Array[Table]) extends IndexedSeq[Table]{
    def apply(index: Int) = items(index)
    def length = items.length
  }

  // Defining implicit formats for json case classes
  implicit val fieldFormat = jsonFormat3(Field)
  implicit val tableFormat = jsonFormat2(Table)

  implicit object tableArrayFormat extends RootJsonFormat[TablesArray] {
    def read(value: JsValue) = TablesArray(value.convertTo[Array[Table]])
    def write(f: TablesArray) = f.items.toJson
  }

  // Call this to parse surrogate key json config
  def parseSurrogateKeyConfig(jsonConfig: String): Seq[Table] =
    jsonConfig.parseJson.convertTo[TablesArray].items
}
