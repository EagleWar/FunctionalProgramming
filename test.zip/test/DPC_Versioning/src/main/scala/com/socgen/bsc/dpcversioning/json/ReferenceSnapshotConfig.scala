package com.socgen.bsc.dpcversioning.json

import spray.json._
case class ReferenceSnapshotConfig(tableName: String, coalesce: Option[Int] = None, idFields: String, refFields: String)

object ReferenceSnapshotConfigParser extends DefaultJsonProtocol {
  case class ArrayReferenceSnapshotConfig(configs: Seq[ReferenceSnapshotConfig])

  implicit object JsonConfigs extends RootJsonFormat[ArrayReferenceSnapshotConfig] {
    implicit val referenceSnapshotFormat: RootJsonFormat[ReferenceSnapshotConfig] = jsonFormat4(ReferenceSnapshotConfig)
    def read(value: JsValue) = ArrayReferenceSnapshotConfig(value.convertTo[List[ReferenceSnapshotConfig]])
    def write(obj: ArrayReferenceSnapshotConfig): JsValue = obj.configs.toJson
  }

  def parseReferenceSnapshotConfigs(jsonConfigs: String): Seq[ReferenceSnapshotConfig] =
    jsonConfigs.parseJson.convertTo[ArrayReferenceSnapshotConfig].configs
}
