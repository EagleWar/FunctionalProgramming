package com.socgen.bsc.dpcversioning

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}

import com.socgen.bsc.dpcversioning.json.{Config, ConfigParser, Field, SurrogateKeyConfigParser}
import com.socgen.bsc.dpc.common.Reporting
import com.socgen.bsc.dpc.common.utility.PropertiesUtility
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.SparkConf
import org.apache.spark.sql.functions.{col, concat_ws, lit}
import org.apache.spark.sql.types.DataType
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

import scala.util.{Failure, Success, Try}

object Main {

  // Properties
  private val jsonConfigPath = "config-path"
  private val reportingOutputPath = "reportingOutputPath"
  private val createDimTimeFlag = "createDimTime"
  private val databaseName = "databaseName"
  private val surrogateKeyPathProperties = "surrogateKeyPath"
  private val dropFieldsProperties = "dropFields"
  private val pathHdfsDatabase = "pathHdfsDatabase"

  val mandatoryProperties: Seq[String] = Seq(jsonConfigPath, reportingOutputPath)

  private val configPathArg = "configPath"
  private val snapshotDateArg = "snapshotDate"
  private val coalesceArg = "coalesce"
  private val defaultCoalesce = 1

  def writeConfig(potentialPath: Option[String], hdfs: FileSystem, reporting: Reporting, currentDateTime: String): Unit =
    potentialPath match {
      case None => None
      case Some(path) =>
        reporting.addFlagTime("Elapsed time")
        val newPath = s"$path/versioning_${currentDateTime}_${System.currentTimeMillis}"
        val os = hdfs.create(new Path(newPath))
        reporting.saveLogs(os)
        os.close()
    }

  def parseArguments(map: Map[String, String], list: List[String]): Map[String, String] = {
    list match {
      case Nil => map
      case ("--config-path" | "-cp") :: path :: tail =>
        parseArguments(map ++ Map(configPathArg -> path), tail)
      case ("--snapshot-date" | "-sd") :: snapshotDate :: tail =>
        parseArguments(map ++ Map(snapshotDateArg -> snapshotDate), tail)
      case unknown :: tail =>
        parseArguments(map, tail)
    }
  }

  def withSurrogateKey(fields: Seq[Field], snapshotDate: String, spark: SparkSession): DataFrame => DataFrame =
    df =>
      fields.foldLeft(df) {
        (acc, field) =>
          val newField = field.newField
          val fieldsToConcat = field.fieldsToConcat.split(",").map(x => col(x))
          val sep = field.sep
          acc.withColumn("snapshot_date", lit(snapshotDate))
            .withColumn(newField, concat_ws(sep, fieldsToConcat: _*))
      }

  /**
    * This function is used to harmonize the schemas of the currentDf DataFrame and the corresponding snapshot table.
    * If they don't match, the missing field(s) are added with the right types.
    *
    * @param currentDf     the current data read from the daily table
    * @param snapshotDf    the dataframe read from the snapshot table (no spark actions are actually executed on this DataFrame
    *                      so due to the lazy nature of spark the data from the snapshot table is never retrieved which
    *                      allows us to compare the schema without unnecessarily reading data.)
    * @param snapshotTable the name of the corresponding snapshot table
    * @param reporting     Reporting object
    * @param spark         SparkSession object
    * @return the harmonize currentDf
    */
  def harmonizeSchema(currentDf: DataFrame,
                      snapshotDf: DataFrame,
                      snapshotTable: String,
                      reporting: Reporting,
                      spark: SparkSession): Option[DataFrame] = {
    val currentFields: Map[String, DataType] = currentDf.schema.map(f => f.name -> f.dataType).toMap
    val snapshotFields: Map[String, DataType] = snapshotDf.schema.map(f => f.name -> f.dataType).toMap

    val harmonizedDf = snapshotFields.foldLeft(currentDf) {
      (accDf: DataFrame, snapshotField) =>
        val snapshotFieldName = snapshotField._1
        val snapshotFieldType = snapshotField._2

        if (currentFields.contains(snapshotFieldName)) {
          val currentType = currentFields(snapshotFieldName)
          if (currentType != snapshotFieldType) {
            // If the currentDf contains the field but the types missmatch the program logs the exception
            reporting.addLog(s"Type conflict with $snapshotTable table on field $snapshotFieldName. Snapshot field type $snapshotFieldType, current field type $currentType")
            return None
          }
          accDf
        } else if (!currentFields.contains(snapshotFieldName) && snapshotFieldName != "snapshot_date") {
          // If a field of the snapshot table is missing in the currentDf, a new column is added to the DataFrame filled with nulls
          accDf.withColumn(snapshotFieldName, lit(null).cast(snapshotFieldType))
        } else accDf
    }

    for ((fname, ftype) <- currentFields) {
      if (!snapshotFields.contains(fname)) {
        spark.sql(s"ALTER TABLE $snapshotTable ADD COLUMNS ($fname ${ftype.simpleString})")
      }
    }
    Some(harmonizedDf)
  }

  def saveAsSnapshotPartition(df: DataFrame,
                              snapshotTable: String,
                              reporting: Reporting,
                              spark: SparkSession,
                              snapshotDate: String,
                              pathDatabase: String,
                              coalesce: Int = defaultCoalesce): Unit = {
    df.withColumn("snapshot_date", lit(snapshotDate))
      .coalesce(coalesce)
      .write
      .mode(SaveMode.Append)
      .option("path",pathDatabase+snapshotTable.split("\\.")(1))
      .partitionBy("snapshot_date")
      .saveAsTable(snapshotTable)

    reporting.addIngestionCount(
      spark.sql(s"SELECT * FROM $snapshotTable WHERE snapshot_date = '$snapshotDate'").count,
      snapshotTable)
  }

  def insertSnapshotToDimTime(dbName: String, 
                              snapshotDate: String, 
                              referenceDate: String, 
                              spark: SparkSession, 
                              pathDatabase: String,
                              coalesce: Int = defaultCoalesce,
                              hdfs: FileSystem): Unit = {
    val dimTable = dbName + ".dim_time"
    val location = pathDatabase+"dim_time"
    import spark.implicits._
    if (!spark.catalog.tableExists(dimTable)) {
      Seq(("-1","Current View",1),(snapshotDate,referenceDate,0)).toDF("id_partition", "reference_date", "flag")
        .coalesce(coalesce)
        .write
        .mode(SaveMode.Overwrite)
        .option("path",location)
        .saveAsTable(dimTable)
    } else {
      val dimTimeDf = spark.sql(s"SELECT * FROM $dimTable")
      val dimTableTmp = dimTable + "_tmp"
      Try {
        dimTimeDf.union(Seq((snapshotDate, referenceDate, 0)).toDF("id_partition", "reference_date", "flag"))
          .dropDuplicates()
          .coalesce(coalesce)
          .write
          .mode(SaveMode.Overwrite)
          .option("path",location+"_tmp")
          .saveAsTable(dimTableTmp)
      } match {
        case Success(_) =>
          spark.sql(s"select * from $dimTableTmp")
            .coalesce(coalesce)
            .write
            .mode(SaveMode.Overwrite)
            .option("path",location)
            .saveAsTable(dimTable)
          spark.sql(s"drop table $dimTableTmp")
          hdfs.delete(new Path(location+"_tmp"))
        case Failure(exception) =>
          throw exception
      }
    }
  }

  def main(args: Array[String]): Unit = {
    val conf = new SparkConf()
      .setAppName("DPC Versioning")
      .setIfMissing("master", "local[*]")

    implicit val spark: SparkSession = SparkSession
      .builder
      .config(conf)
      .enableHiveSupport()
      .getOrCreate

    val reporting = new Reporting("DPC Versioning")
    reporting.addSparkOptions(spark.sparkContext)
    val arguments = parseArguments(Map(), args.toList)
    reporting.addParameters(arguments)

    val now: Date = Calendar.getInstance().getTime
    val snapshotDateFormatter = new SimpleDateFormat("yyyyMMdd")
    val snapshotDate = arguments.get(snapshotDateArg) match {
      case None | Some("default") => snapshotDateFormatter.format(now)
      case Some(value) => value
    }

    val currentDateTime: String = new SimpleDateFormat("yyyyMMdd_hhmmss").format(now)
    val referenceDate: String = new SimpleDateFormat("yyyy-MM-dd").format(snapshotDateFormatter.parse(snapshotDate))

    val hdfs = FileSystem.get(new Configuration())
    val path = new Path(arguments.getOrElse(configPathArg, "no_config_path_found"))
    val inputStream = hdfs.open(path)
    val prop = PropertiesUtility.getProperties(inputStream)

    val coalesce = prop.get(coalesceArg) match {
      case Some(coalesceOpt) => try {
          coalesceOpt.toInt
        } catch {
          case e: Exception => throw new Exception(s"Can't convert coalesce option to integer => ERROR : $e")
        }
      case _ => defaultCoalesce
    }

    try {
      PropertiesUtility.addMandatoryPropertiesToReporting(mandatoryProperties, reporting, prop)

      val jsonConfigs = scala.io.Source.fromInputStream(hdfs.open(new Path(prop(jsonConfigPath)))).mkString
      val configs: Seq[Config] = ConfigParser.parseBasicExtractionConfigs(jsonConfigs)

      val surrogateKey = prop.get(surrogateKeyPathProperties) match {
        case Some(surrogateKeyPath) =>
          val jsonConfigs = scala.io.Source.fromInputStream(hdfs.open(new Path(surrogateKeyPath))).mkString
          SurrogateKeyConfigParser.parseSurrogateKeyConfig(jsonConfigs)
        case None => null
      }

      val dropFields = prop.getOrElse(dropFieldsProperties, "no_fields_to_drop")
      val createDimTime = prop(createDimTimeFlag)
      val dbName = prop(databaseName)
      val pathDatabase = prop(pathHdfsDatabase)

      configs.foreach {
        input =>
          val currentTable = input.tableName
          val snapshotTable = currentTable + "_snapshot"

          val currentDf = spark.sql(s"SELECT * FROM $currentTable")
            .drop(dropFields.split(","): _*)

          val currentDfLower = currentDf.select(currentDf.columns.map(x => col(x).as(x.toLowerCase)): _*)


          val currentSurrogateDf = {
            if (surrogateKey != null) {
              val surrogateKeyFilter = surrogateKey.filter(_.table == snapshotTable)
              if (surrogateKeyFilter.nonEmpty) currentDfLower.transform(withSurrogateKey(surrogateKeyFilter.head.fields, snapshotDate, spark))
              else currentDfLower
            }
            else currentDfLower
          }

          if (spark.catalog.tableExists(snapshotTable)) {
            val snapshotDf = spark.sql(s"SELECT * FROM $snapshotTable")
            harmonizeSchema(currentSurrogateDf, snapshotDf, snapshotTable, reporting, spark)
              .foreach {
                df =>
                  spark.sql(s"ALTER TABLE $snapshotTable DROP IF EXISTS PARTITION (snapshot_date='$snapshotDate')")
                  hdfs.delete(new Path(pathDatabase+snapshotTable.split("\\.")(1)+s"/snapshot_date=$snapshotDate"))
                  saveAsSnapshotPartition(df, snapshotTable, reporting, spark, snapshotDate, pathDatabase, coalesce = input.coalesce.getOrElse(coalesce))
              }
          } else saveAsSnapshotPartition(currentSurrogateDf, snapshotTable, reporting, spark, snapshotDate, pathDatabase, coalesce = input.coalesce.getOrElse(coalesce))
      }

      if (createDimTime == "true") insertSnapshotToDimTime(dbName = dbName, snapshotDate = snapshotDate, referenceDate = referenceDate, spark = spark, pathDatabase = pathDatabase, coalesce = coalesce, hdfs = hdfs)

    } catch {
      case exception: Throwable =>
        reporting.addException(exception)
        writeConfig(prop.get(reportingOutputPath), hdfs, reporting, currentDateTime)
        throw exception
    }

    writeConfig(prop.get(reportingOutputPath), hdfs, reporting, currentDateTime)
    spark.stop
  }

}
