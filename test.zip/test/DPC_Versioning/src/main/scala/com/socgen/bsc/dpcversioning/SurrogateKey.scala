package com.socgen.bsc.dpcversioning
import com.socgen.bsc.dpcversioning.json.{SurrogateKeyConfigParser,Field}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{SparkSession, DataFrame, SaveMode}
import org.apache.spark.sql.functions.{col, concat_ws}
import org.apache.hadoop.fs.{FSDataInputStream, FileSystem, Path}
import org.apache.hadoop.conf.Configuration

object SurrogateKey {

  private val jsonPathArg = "jsonPath"
  private val pathHdfsDatabaseArg = "pathHdfsDatabase"
  private val coalesceArg = "coalesce"
  private val defaultCoalesce : Int = 1

  def parseArguments(map: Map[String, String], list: List[String]): Map[String, String] = {
    list match {
      case Nil => map
      case ("--json-path" | "-jp") :: path :: tail =>
        parseArguments(map ++ Map(jsonPathArg -> path), tail)
      case ("--hdfs-path" | "-hp") :: path :: tail =>
        parseArguments(map ++ Map(pathHdfsDatabaseArg -> path), tail)
      case ("--coalesce" | "-csc") :: coalesce :: tail =>
        parseArguments(map ++ Map(coalesceArg -> coalesce), tail)
      case unknown :: tail =>
        parseArguments(map, tail)
    }
  }

  def concatFields(table: String, fields: Seq[Field], spark: SparkSession): DataFrame =
    fields.foldLeft(spark.sql(s"select * from $table")) {
      (acc, field) =>
        val newField = field.newField
        val fieldsToConcat = field.fieldsToConcat.split(",").map(x => col(x))
        val sep = field.sep
        acc.withColumn(newField, concat_ws(sep,fieldsToConcat:_*))
    }

  def main(args: Array[String]): Unit = {
    val conf = new SparkConf()
      .setAppName("DPC Add Concat Field in Existing Hive Snapshot Table")
      .setIfMissing("master", "local[*]")

    implicit val spark: SparkSession = SparkSession
      .builder
      .config(conf)
      .config("spark.sql.broadcastTimeout", "2000")
      .enableHiveSupport()
      .getOrCreate

    val arguments = parseArguments(Map(), args.toList)
    val hdfs = FileSystem.get(new Configuration())
    val pathDatabase = arguments(pathHdfsDatabaseArg)

    val coalesce = arguments.get(coalesceArg) match {
      case Some(coalesceOpt) => try {
          coalesceOpt.toInt
        } catch {
          case e: Exception => throw new Exception(s"Can't convert coalesce option to integer => ERROR : $e")
        }
      case _ => defaultCoalesce
    }

    val jsonConfigs = scala.io.Source.fromInputStream(hdfs.open(new Path(arguments(jsonPathArg)))).mkString
    val configs = SurrogateKeyConfigParser.parseSurrogateKeyConfig(jsonConfigs)

    configs.foreach {
      config =>
        val table = config.table
        val tableTmp = table+"_tmp"
        val location = pathDatabase+table.split("\\.")(1)

        concatFields(table, config.fields, spark).
          coalesce(defaultCoalesce).
          write.
          mode(SaveMode.Overwrite).
          option("path",location+"_tmp").
          saveAsTable(tableTmp)

        spark.sql(s"select * from $tableTmp").
          coalesce(defaultCoalesce).
            write.
            mode(SaveMode.Overwrite).
            option("path",location).
            partitionBy("snapshot_date").
            saveAsTable(table)

        spark.sql(s"drop table $tableTmp")
        hdfs.delete(new Path(location+"_tmp"))
    }
    
    spark.stop()
  
  }
}