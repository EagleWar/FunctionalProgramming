package com.socgen.bsc.dpcversioning

import com.socgen.bsc.dpcversioning.json.BackfillConfigParser
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

import scala.util.{Failure, Success, Try}

object Backfiller {

  private val jsonPathArg = "jsonPath"
  private val pathHdfsDatabaseArg = "pathHdfsDatabase"
  private val coalesceArg = "coalesce"
  private val defaultCoalesce : Int = 1

  def parseArguments(map: Map[String, String], list: List[String]): Map[String, String] = {
    list match {
      case Nil => map
      case ("--json-path" | "-jp") :: path :: tail =>
        parseArguments(map ++ Map(jsonPathArg -> path), tail)
      case ("--hdfs-path" | "-hp") :: path :: tail =>
        parseArguments(map ++ Map(pathHdfsDatabaseArg -> path), tail)
      case ("--coalesce" | "-csc") :: coalesce :: tail =>
        parseArguments(map ++ Map(coalesceArg -> coalesce), tail)
      case unknown :: tail =>
        parseArguments(map, tail)
    }
  }

  def toInt(s: String): Int = {
    Try {
      s.toInt
    } match {
      case Success(value) => value
      case Failure(exception) =>
        throw exception
    }
  }

  def overwriteSnapshotTable(df: DataFrame, table: String, spark: SparkSession, pathDatabase: String, coalesce: Int = defaultCoalesce, hdfs: FileSystem): Unit = {
    val tableTmp = table + "_tmp"
    val location = pathDatabase+table.split("\\.")(1)
    Try {
      df.coalesce(coalesce).write
        .mode(SaveMode.Overwrite)
        .option("path",location+"_tmp")
        .saveAsTable(tableTmp)
    } match {
      case Success(_) =>
        spark.sql(s"select * from $tableTmp")
          .coalesce(coalesce).write
          .mode(SaveMode.Overwrite)
          .option("path",location)
          .partitionBy("snapshot_date")
          .saveAsTable(table)
        spark.sql(s"drop table $tableTmp")
        hdfs.delete(new Path(location+"_tmp"))
      case Failure(e) =>
        throw e
    }
  }

  def main(args: Array[String]): Unit = {
    val conf = new SparkConf()
      .setAppName("DPC Backfill Hive Table")
      .setIfMissing("master", "local[*]")

    implicit val spark: SparkSession = SparkSession
      .builder
      .config(conf)
      .enableHiveSupport()
      .getOrCreate

    val arguments = parseArguments(Map(), args.toList)
    val hdfs = FileSystem.get(new Configuration())

    val coalesce = arguments.get(coalesceArg) match {
      case Some(coalesceOpt) => try {
          coalesceOpt.toInt
        } catch {
          case e: Exception => throw new Exception(s"Can't convert coalesce option to integer => ERROR : $e")
        }
      case _ => defaultCoalesce
    }

    val jsonConfigs = scala.io.Source.fromInputStream(hdfs.open(new Path(arguments(jsonPathArg)))).mkString
    val pathDatabase = arguments(pathHdfsDatabaseArg)
    val configs = BackfillConfigParser.parseBackfillConfigs(jsonConfigs)


    configs.foreach {
      config =>
        val table = config.tableName
        val fieldsToBackfill = config.fieldsToBackfill.split(",").toList
        val value = if (config.toInt) toInt(config.value) else config.value

        val df = spark.sql(s"SELECT * FROM $table")

        val backfilledDf = if (config.toInt) {
          df.na.fill(toInt(config.value), fieldsToBackfill)
        } else df.na.fill(config.value, fieldsToBackfill)

        overwriteSnapshotTable(df = backfilledDf, table = table, spark = spark, pathDatabase = pathDatabase, coalesce = config.coalesce.getOrElse(coalesce), hdfs = hdfs)
    }

    spark.stop()
  }
}
