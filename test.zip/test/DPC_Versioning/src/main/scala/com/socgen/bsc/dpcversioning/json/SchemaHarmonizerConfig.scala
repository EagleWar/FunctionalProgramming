package com.socgen.bsc.dpcversioning.json

import spray.json._

case class SchemaHarmonizerConfig(tableName: String)

object SchemaHarmonizerConfigParser extends DefaultJsonProtocol {
  case class ArraySchemaHarmonizerConfig(configs: Seq[SchemaHarmonizerConfig])

  implicit object JsonConfigs extends RootJsonFormat[ArraySchemaHarmonizerConfig] {
    implicit val schemaHarmonizerFormat: RootJsonFormat[SchemaHarmonizerConfig] = jsonFormat1(SchemaHarmonizerConfig)
    def read(value: JsValue) = ArraySchemaHarmonizerConfig(value.convertTo[List[SchemaHarmonizerConfig]])
    def write(obj: ArraySchemaHarmonizerConfig): JsValue = obj.configs.toJson
  }

  def parseSchemaHarmonizerConfigs(jsonConfigs: String): Seq[SchemaHarmonizerConfig] =
    jsonConfigs.parseJson.convertTo[ArraySchemaHarmonizerConfig].configs
}
