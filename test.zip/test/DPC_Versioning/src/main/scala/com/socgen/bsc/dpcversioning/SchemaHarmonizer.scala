package com.socgen.bsc.dpcversioning

import com.socgen.bsc.dpcversioning.json.SchemaHarmonizerConfigParser
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.types.DataType
import org.apache.spark.sql.functions.col

object SchemaHarmonizer {

  private val jsonPathArg = "jsonPath"

  def parseArguments(map: Map[String, String], list: List[String]): Map[String, String] = {
    list match {
      case Nil => map
      case ("--json-path" | "-jp") :: path :: tail =>
        parseArguments(map ++ Map(jsonPathArg -> path), tail)
      case unknown :: tail =>
        parseArguments(map, tail)
    }
  }

  def updateSnapshotTableSchema(currentDf: DataFrame, snapshotDf: DataFrame, snapshotTable: String, spark: SparkSession): Unit = {
    val currentFields: Map[String, DataType] = currentDf.schema.map(f => f.name -> f.dataType).toMap
    val snapshotFields: Map[String, DataType] = snapshotDf.schema.map(f => f.name -> f.dataType).toMap

    for ((fname, ftype) <- currentFields) {
      if (!snapshotFields.contains(fname)) {
        spark.sql(s"ALTER TABLE $snapshotTable ADD COLUMNS ($fname ${ftype.simpleString})")
        println(snapshotTable + ": " + fname)
      }
    }
  }

  def main(args: Array[String]): Unit = {
    val conf = new SparkConf()
      .setAppName("DPC Schema Harmonizer")
      .setIfMissing("master", "local[*]")

    implicit val spark: SparkSession = SparkSession
      .builder
      .config(conf)
      .enableHiveSupport()
      .getOrCreate

    val arguments = parseArguments(Map(), args.toList)
    val hdfs = FileSystem.get(new Configuration())

    val jsonConfigs = scala.io.Source.fromInputStream(hdfs.open(new Path(arguments(jsonPathArg)))).mkString
    val configs = SchemaHarmonizerConfigParser.parseSchemaHarmonizerConfigs(jsonConfigs)


    configs.foreach {
      config =>
        val currentTable = config.tableName
        val snapshotTable = currentTable + "_snapshot"

        val currentDf = spark.sql(s"SELECT * FROM $currentTable")
        val snapshotDf = spark.sql(s"SELECT * FROM $snapshotTable")

        val currentDfLower = currentDf.select(currentDf.columns.map(x => col(x).as(x.toLowerCase)): _*)

        updateSnapshotTableSchema(currentDfLower, snapshotDf, snapshotTable, spark)
    }

    spark.stop()
  }
}
