package com.socgen.bsc.dpcversioning

import com.socgen.bsc.dpcversioning.json.ReferenceSnapshotConfigParser
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.SparkConf
import org.apache.spark.sql.functions.when
import org.apache.spark.sql.{SaveMode, SparkSession}

import scala.util.{Failure, Success, Try}

object ReferenceFieldsHarmonizer {

  private val jsonPathArg = "jsonPath"
  private val snapshotDate = "snapshotDate"
  private val pathHdfsDatabaseArg = "pathHdfsDatabase"
  private val coalesceArg = "coalesce"
  private val defaultCoalesce : Int = 1

  def parseArguments(map: Map[String, String], list: List[String]): Map[String, String] = {
    list match {
      case Nil => map
      case ("--json-path" | "-jp") :: path :: tail =>
        parseArguments(map ++ Map(jsonPathArg -> path), tail)
      case ("--snapshot-date" | "-sp") :: date :: tail =>
        parseArguments(map ++ Map(snapshotDate -> date), tail)
      case ("--hdfs-path" | "-hp") :: path :: tail =>
        parseArguments(map ++ Map(pathHdfsDatabaseArg -> path), tail)
      case ("--coalesce" | "-csc") :: coalesce :: tail =>
        parseArguments(map ++ Map(coalesceArg -> coalesce), tail)
      case unknown :: tail =>
        parseArguments(map, tail)
    }
  }

  def main(args: Array[String]): Unit = {
    val conf = new SparkConf()
      .setAppName("DPC Reference Snapshot Tables")
      .setIfMissing("master", "local[*]")

    implicit val spark: SparkSession = SparkSession
      .builder
      .config(conf)
      .enableHiveSupport()
      .getOrCreate

    val arguments = parseArguments(Map(), args.toList)
    val hdfs = FileSystem.get(new Configuration())
    val pathDatabase = arguments(pathHdfsDatabaseArg)
    val jsonConfigs = scala.io.Source.fromInputStream(hdfs.open(new Path(arguments(jsonPathArg)))).mkString
    val configs = ReferenceSnapshotConfigParser.parseReferenceSnapshotConfigs(jsonConfigs)

    val coalesce = arguments.get(coalesceArg) match {
      case Some(coalesceOpt) => try {
          coalesceOpt.toInt
        } catch {
          case e: Exception => throw new Exception(s"Can't convert coalesce option to integer => ERROR : $e")
        }
      case _ => defaultCoalesce
    }

    configs.foreach {
      config =>
        val table = config.tableName
        val snapshotTable = table + "_snapshot"
        val tableTmp = snapshotTable +"_tmp"
        val location = pathDatabase+snapshotTable.split("\\.")(1)

        // id field(s) used to join the current and snapshot tables
        val idFields = config.idFields.split(",").toList
        // fields to update in the snapshots with the values of the current data
        val refFields = config.refFields.split(",").toList
        val refFieldsAlias = refFields.map(field => s"$field AS ${field}_ref")

        // create a list of all the needed fields when reading current reference table
        val selectFields = idFields ::: refFieldsAlias

        // reading the reference date, current table if no snapshot argument was given otherwise the specified partition
        val referenceSnapshot = arguments(snapshotDate)

        val referenceDf = if (referenceSnapshot.length > 0) {
          spark.sql(s"SELECT DISTINCT ${selectFields.mkString(",")} FROM $snapshotTable WHERE snapshot_date = '$referenceSnapshot'")
        } else {
          spark.sql(s"SELECT DISTINCT ${selectFields.mkString(",")} FROM $table")
        }

        val snapshotDf = spark.sql(s"SELECT * FROM $snapshotTable")

        val refSnapshotDf = snapshotDf.join(referenceDf, idFields, "left")

        refSnapshotDf.show()

        val updatedSnapshotDf = refFields.foldLeft(refSnapshotDf) {
          (acc, field) =>
            val fieldAlias = field + "_ref"
            acc.withColumn(field, when(acc.col(fieldAlias).isNull, acc.col(field)).otherwise(acc.col(fieldAlias)))
              .drop(acc.col(fieldAlias))
        }

        Try {
          updatedSnapshotDf.coalesce(config.coalesce.getOrElse(coalesce)).write
          .mode(SaveMode.Overwrite)
          .option("path",location+"_tmp")
          .saveAsTable(tableTmp)
        } match {
          case Success(_) =>
            spark.sql(s"select * from $tableTmp")
              .coalesce(config.coalesce.getOrElse(coalesce)).write
              .mode(SaveMode.Overwrite)
              .option("path",location)
              .partitionBy("snapshot_date")
              .saveAsTable(snapshotTable)
            spark.sql(s"drop table $tableTmp")
            hdfs.delete(new Path(location+"_tmp"))
          case Failure(exception) =>
            throw exception
        }
    }

    spark.stop()
  }
}
