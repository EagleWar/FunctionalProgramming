select
id,
specific_kri_card_id,
covered_period,
status,
comment,
cast(value as int) as value,
common_kri_card_id
from public.production_kri