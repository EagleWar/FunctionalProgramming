package com.socgen.bsc.dpc.collect


import scala.io.Source
import java.sql.DriverManager
import java.util.Properties

import io.eels.component.jdbc.JdbcSource
import io.eels.component.parquet.{ParquetSink, ParquetWriteOptions}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.log4j.{Level, Logger}


object Main
{


    def main(args: Array[String])
    {
        Logger.getLogger("org.apache.parquet.hadoop.ColumnChunkPageWriteStore").setLevel(Level.WARN)
        Logger.getLogger("org.apache.parquet.hadoop.InternalParquetRecordWriter").setLevel(Level.WARN)

        // Argument parsing
        if (args.length != 1)
            throw new IllegalArgumentException("Usage : ./dpc_collect <path/to/config.properties>")

        // Configuration System
        implicit val hadoopConf = new Configuration()
        hadoopConf.set("fs.defaultFS", "file:///")
        implicit val hadoopFileSystem = FileSystem.get(hadoopConf)

        // Reading properties
        val dpcProps: DPCProperties = DPCProperties(args(0))

        // Configuration connection SQL
        val extractor = SQLExtractor(dpcProps)

        // Query extraction
        extractor.executeSqlFolder

        // Recap
        println(extractor.errorRecap)
        println(s"Total error count : ${extractor.errorCount}.")
    }
}